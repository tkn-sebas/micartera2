export interface Partner {
  id: string;
  user_id: string;
  name: string;
  email: string;
  ownership_share: number;
  created_at: string;
}

export interface Client {
  id: string;
  full_name: string;
  id_number: string;
  phone: string | null;
  address: string | null;
  registration_date: string;
  notes: string | null;
  active: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export type LoanFrequency = 'daily' | 'weekly' | 'biweekly' | 'monthly' | 'custom_days' | 'custom_dates';
export type LoanStatus = 'active' | 'completed' | 'cancelled';

export interface Loan {
  id: string;
  client_id: string;
  capital: number;
  interest_rate: number;
  interest_amount: number;
  total_to_recover: number;
  disbursement_date: string;
  term_days: number;
  frequency: LoanFrequency;
  collection_days: string[];
  exclude_sundays: boolean;
  exclude_holidays: boolean;
  custom_dates: string[];
  num_installments: number;
  installment_amount: number;
  last_installment_amount: number;
  capital_paid: number;
  interest_paid: number;
  capital_pending: number;
  interest_pending: number;
  status: LoanStatus;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export type InstallmentStatus = 'pending' | 'partial' | 'paid' | 'overdue';

export interface Installment {
  id: string;
  loan_id: string;
  installment_number: number;
  due_date: string;
  amount: number;
  capital_component: number;
  interest_component: number;
  amount_paid: number;
  status: InstallmentStatus;
  created_at: string;
}

export type PaymentMethod = 'cash' | 'transfer' | 'other';

export interface Payment {
  id: string;
  loan_id: string;
  client_id: string;
  installment_id: string | null;
  amount: number;
  capital_applied: number;
  interest_applied: number;
  payment_date: string;
  payment_time: string;
  payment_method: PaymentMethod;
  notes: string | null;
  is_reversed: boolean;
  reversed_at: string | null;
  created_by: string | null;
  created_at: string;
}

export interface PaymentReversal {
  id: string;
  payment_id: string;
  reason: string;
  reversed_by: string | null;
  reversed_at: string;
}

export type CashTransactionType =
  | 'partner_contribution'
  | 'disbursement'
  | 'payment_received'
  | 'withdrawal'
  | 'expense'
  | 'other_income'
  | 'other_expense'
  | 'profit_distribution';

export interface CashTransaction {
  id: string;
  type: CashTransactionType;
  amount: number;
  direction: 'in' | 'out';
  description: string | null;
  loan_id: string | null;
  payment_id: string | null;
  partner_id: string | null;
  transaction_date: string;
  created_by: string | null;
  created_at: string;
}

export type PartnerTransactionType = 'contribution' | 'withdrawal' | 'profit_distribution' | 'reinvestment';

export interface PartnerTransaction {
  id: string;
  partner_id: string;
  type: PartnerTransactionType;
  amount: number;
  description: string | null;
  transaction_date: string;
  created_by: string | null;
  created_at: string;
}

export interface AuditLogEntry {
  id: string;
  user_id: string | null;
  user_email: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  details: Record<string, unknown> | null;
  created_at: string;
}

export interface LoanWithClient extends Loan {
  client?: Pick<Client, 'id' | 'full_name' | 'id_number' | 'phone'>;
}

export interface InstallmentWithLoan extends Installment {
  loan?: Pick<Loan, 'id' | 'capital' | 'interest_rate'>;
  client?: Pick<Client, 'id' | 'full_name'>;
}

export interface PaymentWithDetails extends Payment {
  client?: Pick<Client, 'id' | 'full_name'>;
  loan?: Pick<Loan, 'id' | 'capital'>;
}

export interface WhatsAppNotification {
  id: string;
  phone: string;
  message: string;
  notification_type: 'reminder' | 'overdue' | 'confirmation';
  status: 'pending' | 'sent' | 'failed';
  sent_at: string | null;
  error_message: string | null;
  created_at: string;
}
