import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Client, Loan, Installment, Payment, CashTransaction, PartnerTransaction, Partner } from '@/types';

export function useClients() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('clients')
      .select('*')
      .order('created_at', { ascending: false });
    setClients((data as Client[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { clients, loading, refresh };
}

export function useLoans() {
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('loans')
      .select('*')
      .order('created_at', { ascending: false });
    setLoans((data as Loan[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { loans, loading, refresh };
}

export function useLoansWithClients() {
  const [loans, setLoans] = useState<(Loan & { client?: Pick<Client, 'id' | 'full_name' | 'id_number' | 'phone'> })[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('loans')
      .select('*, client:clients(id, full_name, id_number, phone)')
      .order('created_at', { ascending: false });
    setLoans((data as (Loan & { client?: Pick<Client, 'id' | 'full_name' | 'id_number' | 'phone'> })[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { loans, loading, refresh };
}

export function useInstallments() {
  const [installments, setInstallments] = useState<Installment[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('installments')
      .select('*')
      .order('due_date', { ascending: true });
    setInstallments((data as Installment[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { installments, loading, refresh };
}

export function useInstallmentsForLoan(loanId: string | null) {
  const [installments, setInstallments] = useState<Installment[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!loanId) { setInstallments([]); setLoading(false); return; }
    setLoading(true);
    const { data } = await supabase
      .from('installments')
      .select('*')
      .eq('loan_id', loanId)
      .order('installment_number', { ascending: true });
    setInstallments((data as Installment[]) ?? []);
    setLoading(false);
  }, [loanId]);

  useEffect(() => { refresh(); }, [refresh]);
  return { installments, loading, refresh };
}

export function usePayments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('payments')
      .select('*')
      .order('created_at', { ascending: false });
    setPayments((data as Payment[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { payments, loading, refresh };
}

export function usePaymentsWithDetails() {
  const [payments, setPayments] = useState<(Payment & { client?: Pick<Client, 'id' | 'full_name'>; loan?: Pick<Loan, 'id'> })[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('payments')
      .select('*, client:clients(id, full_name), loan:loans(id)')
      .order('created_at', { ascending: false });
    setPayments((data as (Payment & { client?: Pick<Client, 'id' | 'full_name'>; loan?: Pick<Loan, 'id'> })[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { payments, loading, refresh };
}

export function useCashTransactions() {
  const [transactions, setTransactions] = useState<CashTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('cash_transactions')
      .select('*')
      .order('created_at', { ascending: false });
    setTransactions((data as CashTransaction[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { transactions, loading, refresh };
}

export function usePartnerTransactions() {
  const [transactions, setTransactions] = useState<PartnerTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('partner_transactions')
      .select('*')
      .order('created_at', { ascending: false });
    setTransactions((data as PartnerTransaction[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { transactions, loading, refresh };
}

export function usePartners() {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('partners')
      .select('*')
      .order('created_at', { ascending: true });
    setPartners((data as Partner[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  return { partners, loading, refresh };
}
