import { useMemo } from 'react';
import {
  Wallet,
  HandCoins,
  TrendingUp,
  Banknote,
  Users,
  AlertTriangle,
  CalendarClock,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { useLoans, useClients, useInstallments, usePayments, useCashTransactions } from '@/hooks/useData';
import type { ViewKey } from '@/components/Layout';

interface DashboardProps {
  onNavigate: (view: ViewKey) => void;
  onNewLoan: () => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { loans } = useLoans();
  const { clients } = useClients();
  const { installments } = useInstallments();
  const { payments } = usePayments();
  const { transactions: cashTx } = useCashTransactions();

  const stats = useMemo(() => {
    const activeLoans = loans.filter((l) => l.status === 'active');
    const capitalOnLoan = activeLoans.reduce((s, l) => s + l.capital_pending, 0);
    const totalPending = activeLoans.reduce((s, l) => s + l.capital_pending + l.interest_pending, 0);
    const interestCollected = payments
      .filter((p) => !p.is_reversed)
      .reduce((s, p) => s + p.interest_applied, 0);

    const cashIn = cashTx.filter((t) => t.direction === 'in').reduce((s, t) => s + t.amount, 0);
    const cashOut = cashTx.filter((t) => t.direction === 'out').reduce((s, t) => s + t.amount, 0);
    const cashAvailable = cashIn - cashOut;

    const activeClients = clients.filter((c) => c.active).length;

    const today = todayISO();
    const paymentsToday = payments
      .filter((p) => !p.is_reversed && p.payment_date === today)
      .reduce((s, p) => s + p.amount, 0);

    const overdueInstallments = installments.filter(
      (i) => (i.status === 'pending' || i.status === 'partial') && i.due_date < today
    );

    const loanIdsWithOverdue = new Set(overdueInstallments.map((i) => i.loan_id));
    const clientsInMora = new Set(
      activeLoans.filter((l) => loanIdsWithOverdue.has(l.id)).map((l) => l.client_id)
    ).size;

    const upcomingInstallments = installments
      .filter((i) => i.status !== 'paid' && i.due_date >= today)
      .sort((a, b) => a.due_date.localeCompare(b.due_date))
      .slice(0, 8);

    const overdueList = overdueInstallments
      .sort((a, b) => a.due_date.localeCompare(b.due_date))
      .slice(0, 8);

    return {
      cashAvailable,
      capitalOnLoan,
      totalPending,
      interestCollected,
      activeClients,
      activeLoansCount: activeLoans.length,
      clientsInMora,
      paymentsToday,
      upcomingInstallments,
      overdueList,
    };
  }, [loans, clients, installments, payments, cashTx]);

  const cards = [
    {
      label: 'Disponible en Caja',
      value: formatCOP(stats.cashAvailable),
      icon: Wallet,
      color: 'bg-blue-600',
      view: 'cash' as ViewKey,
    },
    {
      label: 'Capital Prestado',
      value: formatCOP(stats.capitalOnLoan),
      icon: HandCoins,
      color: 'bg-indigo-600',
      view: 'loans' as ViewKey,
    },
    {
      label: 'Pendiente por Recuperar',
      value: formatCOP(stats.totalPending),
      icon: TrendingUp,
      color: 'bg-amber-600',
      view: 'loans' as ViewKey,
    },
    {
      label: 'Intereses Cobrados',
      value: formatCOP(stats.interestCollected),
      icon: Banknote,
      color: 'bg-emerald-600',
      view: 'payments' as ViewKey,
    },
    {
      label: 'Clientes Activos',
      value: String(stats.activeClients),
      icon: Users,
      color: 'bg-slate-700',
      view: 'clients' as ViewKey,
    },
    {
      label: 'Préstamos Vigentes',
      value: String(stats.activeLoansCount),
      icon: HandCoins,
      color: 'bg-blue-700',
      view: 'loans' as ViewKey,
    },
    {
      label: 'Clientes en Mora',
      value: String(stats.clientsInMora),
      icon: AlertTriangle,
      color: 'bg-red-600',
      view: 'mora' as ViewKey,
    },
    {
      label: 'Pagos Recibidos Hoy',
      value: formatCOP(stats.paymentsToday),
      icon: CalendarClock,
      color: 'bg-green-600',
      view: 'payments' as ViewKey,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <button
              key={card.label}
              onClick={() => onNavigate(card.view)}
              className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 text-left hover:shadow-md transition-shadow group"
            >
              <div className={`w-10 h-10 ${card.color} rounded-lg flex items-center justify-center mb-3`}>
                <Icon className="text-white" size={20} />
              </div>
              <p className="text-xs text-slate-500 font-medium mb-1">{card.label}</p>
              <p className="text-lg lg:text-xl font-bold text-slate-900 truncate">{card.value}</p>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        {/* Upcoming collections */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="flex items-center gap-2 px-5 py-4 border-b border-slate-200">
            <CalendarClock className="text-blue-600" size={20} />
            <h3 className="font-semibold text-slate-900">Cobros Próximos</h3>
          </div>
          <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
            {stats.upcomingInstallments.length === 0 ? (
              <p className="px-5 py-6 text-sm text-slate-400 text-center">No hay cobros próximos</p>
            ) : (
              stats.upcomingInstallments.map((inst) => {
                const loan = loans.find((l) => l.id === inst.loan_id);
                const client = loan ? clients.find((c) => c.id === loan.client_id) : null;
                return (
                  <div key={inst.id} className="px-5 py-3 flex items-center justify-between">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-800 truncate">
                        {client?.full_name ?? 'Cliente'}
                      </p>
                      <p className="text-xs text-slate-500">Cuota #{inst.installment_number} · {formatDate(inst.due_date)}</p>
                    </div>
                    <span className="text-sm font-semibold text-slate-700 ml-2 whitespace-nowrap">
                      {formatCOP(inst.amount - inst.amount_paid)}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Overdue collections */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="flex items-center gap-2 px-5 py-4 border-b border-slate-200">
            <AlertTriangle className="text-red-600" size={20} />
            <h3 className="font-semibold text-slate-900">Cobros Vencidos</h3>
          </div>
          <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
            {stats.overdueList.length === 0 ? (
              <p className="px-5 py-6 text-sm text-slate-400 text-center">No hay cobros vencidos</p>
            ) : (
              stats.overdueList.map((inst) => {
                const loan = loans.find((l) => l.id === inst.loan_id);
                const client = loan ? clients.find((c) => c.id === loan.client_id) : null;
                return (
                  <div key={inst.id} className="px-5 py-3 flex items-center justify-between">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-800 truncate">
                        {client?.full_name ?? 'Cliente'}
                      </p>
                      <p className="text-xs text-red-500">Venció el {formatDate(inst.due_date)}</p>
                    </div>
                    <span className="text-sm font-semibold text-red-600 ml-2 whitespace-nowrap">
                      {formatCOP(inst.amount - inst.amount_paid)}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Cash flow summary */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4">Resumen de Caja</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <ArrowUpRight className="text-green-600" size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Entradas</p>
              <p className="text-sm font-bold text-green-600">{formatCOP(stats.cashAvailable + stats.capitalOnLoan)}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <ArrowDownRight className="text-red-600" size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Salidas</p>
              <p className="text-sm font-bold text-red-600">{formatCOP(stats.capitalOnLoan)}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Wallet className="text-blue-600" size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500">Disponible</p>
              <p className="text-sm font-bold text-blue-600">{formatCOP(stats.cashAvailable)}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
