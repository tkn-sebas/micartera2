import { useState, FormEvent } from 'react';
import { useClients, useLoans, usePayments } from '@/hooks/useData';
import { supabase } from '@/lib/supabase';
import { logAudit } from '@/lib/audit';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { Modal, ConfirmModal } from '@/components/Modal';
import { Users, Plus, Search, Phone, MapPin, FileText, Eye, Edit, Ban } from 'lucide-react';
import type { Client } from '@/types';

const EMPTY_FORM = {
  full_name: '',
  id_number: '',
  phone: '',
  address: '',
  registration_date: todayISO(),
  notes: '',
};

export function Clients() {
  const { clients, loading, refresh } = useClients();
  const { loans } = useLoans();
  const { payments } = usePayments();
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editClient, setEditClient] = useState<Client | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [detailClient, setDetailClient] = useState<Client | null>(null);
  const [deactivateClient, setDeactivateClient] = useState<Client | null>(null);

  const filtered = clients.filter((c) => {
    const q = search.toLowerCase();
    return (
      c.full_name.toLowerCase().includes(q) ||
      c.id_number.includes(q) ||
      (c.phone ?? '').includes(q)
    );
  });

  function openNew() {
    setEditClient(null);
    setForm(EMPTY_FORM);
    setError(null);
    setModalOpen(true);
  }

  function openEdit(client: Client) {
    setEditClient(client);
    setForm({
      full_name: client.full_name,
      id_number: client.id_number,
      phone: client.phone ?? '',
      address: client.address ?? '',
      registration_date: client.registration_date,
      notes: client.notes ?? '',
    });
    setError(null);
    setModalOpen(true);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!form.full_name.trim()) { setError('El nombre es obligatorio'); return; }
    if (!form.id_number.trim()) { setError('El número de identificación es obligatorio'); return; }

    setSaving(true);

    if (editClient) {
      const { error: err } = await supabase
        .from('clients')
        .update({
          full_name: form.full_name.trim(),
          id_number: form.id_number.trim(),
          phone: form.phone.trim() || null,
          address: form.address.trim() || null,
          registration_date: form.registration_date,
          notes: form.notes.trim() || null,
        })
        .eq('id', editClient.id);

      if (err) { setError(err.message); setSaving(false); return; }
      await logAudit('update', 'client', editClient.id, { name: form.full_name });
    } else {
      const { data, error: err } = await supabase
        .from('clients')
        .insert({
          full_name: form.full_name.trim(),
          id_number: form.id_number.trim(),
          phone: form.phone.trim() || null,
          address: form.address.trim() || null,
          registration_date: form.registration_date,
          notes: form.notes.trim() || null,
        })
        .select()
        .single();

      if (err) { setError(err.message); setSaving(false); return; }
      await logAudit('create', 'client', data.id, { name: form.full_name });
    }

    setSaving(false);
    setModalOpen(false);
    refresh();
  }

  async function toggleActive(client: Client) {
    await supabase.from('clients').update({ active: !client.active }).eq('id', client.id);
    await logAudit(!client.active ? 'activate' : 'deactivate', 'client', client.id);
    refresh();
  }

  const clientLoans = (clientId: string) => loans.filter((l) => l.client_id === clientId);
  const clientPayments = (clientId: string) => payments.filter((p) => p.client_id === clientId && !p.is_reversed);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nombre, identificación o teléfono..."
            className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
          />
        </div>
        <button
          onClick={openNew}
          className="flex items-center justify-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
        >
          <Plus size={18} />
          Nuevo Cliente
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Cargando clientes...</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Users className="mx-auto text-slate-300 mb-3" size={48} />
          <p className="text-slate-500">No hay clientes registrados</p>
          <p className="text-slate-400 text-sm mt-1">Haga clic en "Nuevo Cliente" para comenzar</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((client) => {
            const cLoans = clientLoans(client.id);
            const cPayments = clientPayments(client.id);
            const totalBorrowed = cLoans.reduce((s, l) => s + l.capital, 0);
            const totalPaid = cPayments.reduce((s, p) => s + p.amount, 0);
            return (
              <div
                key={client.id}
                className={`bg-white rounded-xl shadow-sm border p-5 ${
                  client.active ? 'border-slate-200' : 'border-slate-200 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="min-w-0">
                    <h3 className="font-semibold text-slate-900 truncate">{client.full_name}</h3>
                    <p className="text-xs text-slate-500">CC: {client.id_number}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    client.active ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {client.active ? 'Activo' : 'Inactivo'}
                  </span>
                </div>

                <div className="space-y-1.5 text-sm text-slate-600 mb-3">
                  {client.phone && (
                    <div className="flex items-center gap-2"><Phone size={14} className="text-slate-400" /> {client.phone}</div>
                  )}
                  {client.address && (
                    <div className="flex items-center gap-2"><MapPin size={14} className="text-slate-400" /> {client.address}</div>
                  )}
                  <div className="flex items-center gap-2"><FileText size={14} className="text-slate-400" /> Registrado: {formatDate(client.registration_date)}</div>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-3 text-center">
                  <div className="bg-slate-50 rounded-lg py-2">
                    <p className="text-xs text-slate-500">Préstamos</p>
                    <p className="text-sm font-bold text-slate-800">{cLoans.length}</p>
                  </div>
                  <div className="bg-slate-50 rounded-lg py-2">
                    <p className="text-xs text-slate-500">Prestado</p>
                    <p className="text-sm font-bold text-blue-700">{formatCOP(totalBorrowed)}</p>
                  </div>
                  <div className="bg-slate-50 rounded-lg py-2">
                    <p className="text-xs text-slate-500">Pagado</p>
                    <p className="text-sm font-bold text-green-700">{formatCOP(totalPaid)}</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setDetailClient(client)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                  >
                    <Eye size={15} /> Ver
                  </button>
                  <button
                    onClick={() => openEdit(client)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 text-sm font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                  >
                    <Edit size={15} /> Editar
                  </button>
                  <button
                    onClick={() => setDeactivateClient(client)}
                    className="flex items-center justify-center px-3 py-2 text-sm font-medium text-slate-500 hover:text-red-600 bg-slate-100 hover:bg-red-50 rounded-lg transition-colors"
                    title={client.active ? 'Desactivar' : 'Activar'}
                  >
                    <Ban size={15} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create/Edit Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editClient ? 'Editar Cliente' : 'Nuevo Cliente'}
        size="md"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Nombre completo *</label>
            <input
              type="text"
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Número de identificación *</label>
            <input
              type="text"
              value={form.id_number}
              onChange={(e) => setForm({ ...form, id_number: e.target.value })}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              required
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Teléfono</label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Fecha de registro</label>
              <input
                type="date"
                value={form.registration_date}
                onChange={(e) => setForm({ ...form, registration_date: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Dirección</label>
            <input
              type="text"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Observaciones</label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={3}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none resize-none"
            />
          </div>
          {error && <div className="text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg p-3">{error}</div>}
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-medium disabled:opacity-50">
              {saving ? 'Guardando...' : editClient ? 'Actualizar' : 'Guardar'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Detail Modal */}
      <Modal
        open={!!detailClient}
        onClose={() => setDetailClient(null)}
        title="Detalle del Cliente"
        size="lg"
      >
        {detailClient && (
          <div className="space-y-5">
            <div className="bg-slate-50 rounded-lg p-4">
              <h3 className="font-bold text-lg text-slate-900">{detailClient.full_name}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 text-sm text-slate-600">
                <p>Identificación: {detailClient.id_number}</p>
                <p>Teléfono: {detailClient.phone ?? 'N/A'}</p>
                <p>Dirección: {detailClient.address ?? 'N/A'}</p>
                <p>Registro: {formatDate(detailClient.registration_date)}</p>
              </div>
              {detailClient.notes && (
                <p className="text-sm text-slate-600 mt-2 italic">"{detailClient.notes}"</p>
              )}
            </div>

            <div>
              <h4 className="font-semibold text-slate-800 mb-2">Historial de Préstamos</h4>
              {clientLoans(detailClient.id).length === 0 ? (
                <p className="text-sm text-slate-400">Sin préstamos registrados</p>
              ) : (
                <div className="space-y-2">
                  {clientLoans(detailClient.id).map((loan) => (
                    <div key={loan.id} className="flex items-center justify-between border border-slate-200 rounded-lg px-4 py-2.5">
                      <div>
                        <p className="text-sm font-medium text-slate-800">Capital: {formatCOP(loan.capital)}</p>
                        <p className="text-xs text-slate-500">{formatDate(loan.disbursement_date)} · {loan.status}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-slate-500">Pendiente</p>
                        <p className="text-sm font-semibold text-amber-600">{formatCOP(loan.capital_pending + loan.interest_pending)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <h4 className="font-semibold text-slate-800 mb-2">Historial de Pagos</h4>
              {clientPayments(detailClient.id).length === 0 ? (
                <p className="text-sm text-slate-400">Sin pagos registrados</p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {clientPayments(detailClient.id).map((p) => (
                    <div key={p.id} className="flex items-center justify-between border border-slate-200 rounded-lg px-4 py-2.5">
                      <div>
                        <p className="text-sm font-medium text-slate-800">{formatCOP(p.amount)}</p>
                        <p className="text-xs text-slate-500">{formatDate(p.payment_date)} · {p.payment_method}</p>
                      </div>
                      <span className="text-xs text-green-600 font-medium">Capital: {formatCOP(p.capital_applied)} · Interés: {formatCOP(p.interest_applied)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      <ConfirmModal
        open={!!deactivateClient}
        onClose={() => setDeactivateClient(null)}
        onConfirm={() => deactivateClient && toggleActive(deactivateClient)}
        title={deactivateClient?.active ? 'Desactivar Cliente' : 'Activar Cliente'}
        message={deactivateClient?.active
          ? `¿Desactivar a ${deactivateClient?.full_name}? No aparecerá en nuevos préstamos.`
          : `¿Activar a ${deactivateClient?.full_name}?`}
        confirmText={deactivateClient?.active ? 'Desactivar' : 'Activar'}
      />
    </div>
  );
}
