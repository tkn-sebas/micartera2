import { useMemo, useState } from 'react';
import { useClients, useLoans, usePayments, useCashTransactions, useInstallments } from '@/hooks/useData';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { FileBarChart, FileSpreadsheet, FileText, Download } from 'lucide-react';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

type ReportType = 'clients' | 'loans' | 'payments' | 'cash' | 'mora' | 'summary';

const REPORT_OPTIONS: { value: ReportType; label: string; description: string }[] = [
  { value: 'summary', label: 'Resumen General', description: 'Indicadores financieros principales' },
  { value: 'clients', label: 'Clientes', description: 'Listado completo de clientes' },
  { value: 'loans', label: 'Préstamos', description: 'Todos los préstamos registrados' },
  { value: 'payments', label: 'Pagos', description: 'Historial de pagos recibidos' },
  { value: 'cash', label: 'Caja', description: 'Movimientos de caja' },
  { value: 'mora', label: 'Mora', description: 'Cuotas vencidas' },
];

export function Reports() {
  const { clients } = useClients();
  const { loans } = useLoans();
  const { payments } = usePayments();
  const { transactions: cashTx } = useCashTransactions();
  const { installments } = useInstallments();
  const [selected, setSelected] = useState<ReportType>('summary');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const reportData = useMemo(() => {
    const today = todayISO();

    if (selected === 'clients') {
      return clients.map((c) => ({
        Nombre: c.full_name,
        Identificación: c.id_number,
        Teléfono: c.phone ?? '',
        Dirección: c.address ?? '',
        Registro: c.registration_date,
        Estado: c.active ? 'Activo' : 'Inactivo',
      }));
    }

    if (selected === 'loans') {
      return loans.map((l) => {
        const client = clients.find((c) => c.id === l.client_id);
        return {
          Cliente: client?.full_name ?? '',
          Capital: l.capital,
          'Interés %': l.interest_rate,
          'Interés Total': l.interest_amount,
          'Total a Recuperar': l.total_to_recover,
          'Capital Pagado': l.capital_paid,
          'Interés Pagado': l.interest_paid,
          'Capital Pendiente': l.capital_pending,
          'Interés Pendiente': l.interest_pending,
          'Fecha Desembolso': l.disbursement_date,
          Plazo: `${l.term_days} días`,
          Cuotas: l.num_installments,
          Estado: l.status === 'active' ? 'Vigente' : l.status === 'completed' ? 'Completado' : 'Cancelado',
        };
      });
    }

    if (selected === 'payments') {
      let filtered = payments;
      if (dateFrom) filtered = filtered.filter((p) => p.payment_date >= dateFrom);
      if (dateTo) filtered = filtered.filter((p) => p.payment_date <= dateTo);
      return filtered.map((p) => {
        const client = clients.find((c) => c.id === p.client_id);
        return {
          Fecha: p.payment_date,
          Cliente: client?.full_name ?? '',
          Valor: p.amount,
          Capital: p.capital_applied,
          Interés: p.interest_applied,
          Método: p.payment_method === 'cash' ? 'Efectivo' : p.payment_method === 'transfer' ? 'Transferencia' : 'Otro',
          Estado: p.is_reversed ? 'Revertido' : 'Activo',
        };
      });
    }

    if (selected === 'cash') {
      let filtered = cashTx;
      if (dateFrom) filtered = filtered.filter((t) => t.transaction_date >= dateFrom);
      if (dateTo) filtered = filtered.filter((t) => t.transaction_date <= dateTo);
      return filtered.map((t) => ({
        Fecha: t.transaction_date,
        Tipo: t.type.replace(/_/g, ' '),
        Descripción: t.description ?? '',
        Valor: t.amount,
        Dirección: t.direction === 'in' ? 'Entrada' : 'Salida',
      }));
    }

    if (selected === 'mora') {
      const overdue = installments.filter(
        (i) => (i.status === 'pending' || i.status === 'partial') && i.due_date < today
      );
      return overdue.map((i) => {
        const loan = loans.find((l) => l.id === i.loan_id);
        const client = loan ? clients.find((c) => c.id === loan.client_id) : null;
        return {
          Cliente: client?.full_name ?? '',
          'Cuota #': i.installment_number,
          Vencimiento: i.due_date,
          'Valor Cuota': i.amount,
          Pagado: i.amount_paid,
          Pendiente: i.amount - i.amount_paid,
        };
      });
    }

    // Summary
    const activeLoans = loans.filter((l) => l.status === 'active');
    const capitalOnLoan = activeLoans.reduce((s, l) => s + l.capital_pending, 0);
    const totalPending = activeLoans.reduce((s, l) => s + l.capital_pending + l.interest_pending, 0);
    const interestCollected = payments.filter((p) => !p.is_reversed).reduce((s, p) => s + p.interest_applied, 0);
    const cashIn = cashTx.filter((t) => t.direction === 'in').reduce((s, t) => s + t.amount, 0);
    const cashOut = cashTx.filter((t) => t.direction === 'out').reduce((s, t) => s + t.amount, 0);
    return [
      { Indicador: 'Dinero disponible en caja', Valor: cashIn - cashOut },
      { Indicador: 'Capital actualmente prestado', Valor: capitalOnLoan },
      { Indicador: 'Total pendiente por recuperar', Valor: totalPending },
      { Indicador: 'Intereses cobrados', Valor: interestCollected },
      { Indicador: 'Clientes activos', Valor: clients.filter((c) => c.active).length },
      { Indicador: 'Préstamos vigentes', Valor: activeLoans.length },
      { Indicador: 'Total entradas de caja', Valor: cashIn },
      { Indicador: 'Total salidas de caja', Valor: cashOut },
    ];
  }, [selected, clients, loans, payments, cashTx, installments, dateFrom, dateTo]);

  function exportExcel() {
    const ws = XLSX.utils.json_to_sheet(reportData);
    const wb = XLSX.utils.book_new();
    const sheetName = REPORT_OPTIONS.find((r) => r.value === selected)?.label ?? 'Reporte';
    XLSX.utils.book_append_sheet(wb, ws, sheetName.substring(0, 31));
    XLSX.writeFile(wb, `MI_CARTERA_${selected}_${todayISO()}.xlsx`);
  }

  function exportPDF() {
    const doc = new jsPDF();
    const reportLabel = REPORT_OPTIONS.find((r) => r.value === selected)?.label ?? 'Reporte';

    doc.setFontSize(18);
    doc.text('MI CARTERA', 14, 20);
    doc.setFontSize(12);
    doc.text(`Reporte: ${reportLabel}`, 14, 28);
    doc.setFontSize(9);
    doc.text(`Fecha de generación: ${formatDate(todayISO())}`, 14, 34);

    const headers = reportData.length > 0 ? Object.keys(reportData[0]) : [];
    const rows = reportData.map((row) => headers.map((h) => String(row[h as keyof typeof row] ?? '')));

    autoTable(doc, {
      head: [headers],
      body: rows,
      startY: 40,
      styles: { fontSize: 7 },
      headStyles: { fillColor: [30, 64, 175] },
      alternateRowStyles: { fillColor: [240, 245, 255] },
    });

    doc.save(`MI_CARTERA_${selected}_${todayISO()}.pdf`);
  }

  const showDateFilter = selected === 'payments' || selected === 'cash';

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <FileBarChart size={20} className="text-blue-600" />
          Generar Reporte
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
          {REPORT_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setSelected(opt.value)}
              className={`text-left p-4 rounded-lg border transition-colors ${
                selected === opt.value
                  ? 'bg-blue-50 border-blue-600 ring-1 ring-blue-600'
                  : 'bg-white border-slate-200 hover:bg-slate-50'
              }`}
            >
              <p className="font-medium text-slate-800 text-sm">{opt.label}</p>
              <p className="text-xs text-slate-500 mt-0.5">{opt.description}</p>
            </button>
          ))}
        </div>

        {showDateFilter && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Desde</label>
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Hasta</label>
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              />
            </div>
          </div>
        )}

        <div className="flex gap-3">
          <button
            onClick={exportExcel}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
          >
            <FileSpreadsheet size={18} />
            Exportar Excel
          </button>
          <button
            onClick={exportPDF}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
          >
            <FileText size={18} />
            Exportar PDF
          </button>
        </div>
      </div>

      {/* Preview table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-semibold text-slate-900">
            Vista previa: {REPORT_OPTIONS.find((r) => r.value === selected)?.label}
          </h3>
          <span className="text-sm text-slate-400">{reportData.length} registros</span>
        </div>
        <div className="overflow-x-auto max-h-96">
          {reportData.length === 0 ? (
            <p className="px-5 py-8 text-center text-slate-400">No hay datos para mostrar</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 sticky top-0">
                <tr>
                  {Object.keys(reportData[0]).map((key) => (
                    <th key={key} className="text-left px-4 py-2 font-medium text-slate-600 whitespace-nowrap">
                      {key}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {reportData.slice(0, 100).map((row, i) => (
                  <tr key={i}>
                    {Object.values(row).map((val, j) => (
                      <td key={j} className="px-4 py-2 text-slate-700 whitespace-nowrap">
                        {typeof val === 'number' ? formatCOP(val) : String(val)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        {reportData.length > 100 && (
          <div className="px-5 py-2 text-xs text-slate-400 text-center border-t border-slate-100">
            Mostrando 100 de {reportData.length} registros. Exporte para ver todos.
          </div>
        )}
      </div>
    </div>
  );
}
