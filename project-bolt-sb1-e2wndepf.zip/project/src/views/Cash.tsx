import { useState, FormEvent, useMemo } from 'react';
import { useCashTransactions } from '@/hooks/useData';
import { usePartners } from '@/hooks/useData';
import { supabase } from '@/lib/supabase';
import { logAudit } from '@/lib/audit';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { Modal } from '@/components/Modal';
import { Wallet, Plus, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import type { CashTransactionType } from '@/types';

const TX_TYPES: { value: CashTransactionType; label: string; direction: 'in' | 'out' }[] = [
  { value: 'partner_contribution', label: 'Aporte de socios', direction: 'in' },
  { value: 'other_income', label: 'Otros ingresos', direction: 'in' },
  { value: 'withdrawal', label: 'Retiro', direction: 'out' },
  { value: 'expense', label: 'Gasto', direction: 'out' },
  { value: 'other_expense', label: 'Otro egreso', direction: 'out' },
  { value: 'profit_distribution', label: 'Distribución de utilidades', direction: 'out' },
];

const TX_LABELS: Record<string, string> = {
  partner_contribution: 'Aporte de socios',
  disbursement: 'Desembolso',
  payment_received: 'Pago recibido',
  withdrawal: 'Retiro',
  expense: 'Gasto',
  other_income: 'Otro ingreso',
  other_expense: 'Otro egreso',
  profit_distribution: 'Distribución de utilidades',
};

export function Cash() {
  const { transactions, loading, refresh } = useCashTransactions();
  const { partners } = usePartners();
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    type: 'partner_contribution' as CashTransactionType,
    amount: '',
    description: '',
    transaction_date: todayISO(),
    partner_id: '',
  });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const summary = useMemo(() => {
    const cashIn = transactions.filter((t) => t.direction === 'in').reduce((s, t) => s + t.amount, 0);
    const cashOut = transactions.filter((t) => t.direction === 'out').reduce((s, t) => s + t.amount, 0);
    const available = cashIn - cashOut;

    const disbursements = transactions.filter((t) => t.type === 'disbursement').reduce((s, t) => s + t.amount, 0);
    const paymentsReceived = transactions.filter((t) => t.type === 'payment_received').reduce((s, t) => s + t.amount, 0);
    const expenses = transactions.filter((t) => t.type === 'expense' || t.type === 'other_expense').reduce((s, t) => s + t.amount, 0);

    return { cashIn, cashOut, available, disbursements, paymentsReceived, expenses };
  }, [transactions]);

  function openModal() {
    setForm({
      type: 'partner_contribution',
      amount: '',
      description: '',
      transaction_date: todayISO(),
      partner_id: '',
    });
    setError(null);
    setModalOpen(true);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    const amount = parseFloat(form.amount);
    if (!amount || amount <= 0) { setError('El valor debe ser mayor a 0'); return; }

    const txType = TX_TYPES.find((t) => t.value === form.type);
    if (!txType) { setError('Tipo de movimiento inválido'); return; }

    setSaving(true);

    const { data, error: err } = await supabase
      .from('cash_transactions')
      .insert({
        type: form.type,
        amount: Math.round(amount),
        direction: txType.direction,
        description: form.description.trim() || null,
        transaction_date: form.transaction_date,
        partner_id: form.partner_id || null,
      })
      .select()
      .single();

    if (err) { setError(err.message); setSaving(false); return; }

    // If partner contribution or withdrawal, also create partner transaction
    if (form.type === 'partner_contribution' && form.partner_id) {
      await supabase.from('partner_transactions').insert({
        partner_id: form.partner_id,
        type: 'contribution',
        amount: Math.round(amount),
        description: form.description.trim() || 'Aporte de capital',
        transaction_date: form.transaction_date,
      });
    }
    if (form.type === 'withdrawal' && form.partner_id) {
      await supabase.from('partner_transactions').insert({
        partner_id: form.partner_id,
        type: 'withdrawal',
        amount: Math.round(amount),
        description: form.description.trim() || 'Retiro',
        transaction_date: form.transaction_date,
      });
    }

    await logAudit('create', 'cash_transaction', data.id, { type: form.type, amount });

    setSaving(false);
    setModalOpen(false);
    refresh();
  }

  return (
    <div className="space-y-4">
      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-4 text-white">
          <Wallet className="mb-2 opacity-80" size={20} />
          <p className="text-xs text-blue-100">Disponible en caja</p>
          <p className="text-xl font-bold">{formatCOP(summary.available)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <ArrowUpRight className="mb-2 text-green-500" size={20} />
          <p className="text-xs text-slate-500">Entradas</p>
          <p className="text-lg font-bold text-green-600">{formatCOP(summary.cashIn)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <ArrowDownRight className="mb-2 text-red-500" size={20} />
          <p className="text-xs text-slate-500">Salidas</p>
          <p className="text-lg font-bold text-red-600">{formatCOP(summary.cashOut)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <Wallet className="mb-2 text-blue-500" size={20} />
          <p className="text-xs text-slate-500">Pagos recibidos</p>
          <p className="text-lg font-bold text-blue-700">{formatCOP(summary.paymentsReceived)}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Desembolsos</p>
          <p className="text-lg font-bold text-slate-700">{formatCOP(summary.disbursements)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Gastos</p>
          <p className="text-lg font-bold text-slate-700">{formatCOP(summary.expenses)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Total movimientos</p>
          <p className="text-lg font-bold text-slate-700">{transactions.length}</p>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={openModal}
          className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
        >
          <Plus size={18} />
          Nuevo Movimiento
        </button>
      </div>

      {/* Transactions list */}
      {loading ? (
        <div className="text-center py-12 text-slate-400">Cargando movimientos...</div>
      ) : transactions.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Wallet className="mx-auto text-slate-300 mb-3" size={48} />
          <p className="text-slate-500">No hay movimientos de caja</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left px-4 py-3 font-medium text-slate-600">Fecha</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-600">Tipo</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-600">Descripción</th>
                  <th className="text-right px-4 py-3 font-medium text-slate-600">Valor</th>
                  <th className="text-center px-4 py-3 font-medium text-slate-600">Dirección</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {transactions.map((t) => (
                  <tr key={t.id}>
                    <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{formatDate(t.transaction_date)}</td>
                    <td className="px-4 py-3 text-slate-700">{TX_LABELS[t.type] ?? t.type}</td>
                    <td className="px-4 py-3 text-slate-500 max-w-xs truncate">{t.description ?? '-'}</td>
                    <td className="px-4 py-3 text-right font-semibold text-slate-800">{formatCOP(t.amount)}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-flex items-center gap-1 text-xs font-medium ${
                        t.direction === 'in' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {t.direction === 'in' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                        {t.direction === 'in' ? 'Entrada' : 'Salida'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* New Transaction Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Nuevo Movimiento de Caja" size="md">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Tipo de movimiento *</label>
            <select
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value as CashTransactionType })}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
            >
              {TX_TYPES.map((t) => (
                <option key={t.value} value={t.value}>{t.label} ({t.direction === 'in' ? 'Entrada' : 'Salida'})</option>
              ))}
            </select>
          </div>

          {(form.type === 'partner_contribution' || form.type === 'withdrawal') && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Socio</label>
              <select
                value={form.partner_id}
                onChange={(e) => setForm({ ...form, partner_id: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              >
                <option value="">Seleccione socio</option>
                {partners.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Valor (COP) *</label>
              <input
                type="number"
                step="any"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Fecha</label>
              <input
                type="date"
                value={form.transaction_date}
                onChange={(e) => setForm({ ...form, transaction_date: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Descripción</label>
            <input
              type="text"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
            />
          </div>

          {error && <div className="text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg p-3">{error}</div>}

          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-medium disabled:opacity-50">
              {saving ? 'Guardando...' : 'Guardar'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
