import { useState, FormEvent, useMemo } from 'react';
import { usePartners, usePartnerTransactions, usePayments, useCashTransactions } from '@/hooks/useData';
import { supabase } from '@/lib/supabase';
import { logAudit } from '@/lib/audit';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { Modal } from '@/components/Modal';
import { PieChart, Plus, RotateCcw } from 'lucide-react';
import type { PartnerTransactionType } from '@/types';

export function Profits() {
  const { partners } = usePartners();
  const { transactions, refresh } = usePartnerTransactions();
  const { payments } = usePayments();
  const { transactions: cashTx, refresh: refreshCash } = useCashTransactions();
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({
    partner_id: '',
    type: 'profit_distribution' as PartnerTransactionType,
    amount: '',
    description: '',
    transaction_date: todayISO(),
  });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const profitData = useMemo(() => {
    const totalInterestCollected = payments
      .filter((p) => !p.is_reversed)
      .reduce((s, p) => s + p.interest_applied, 0);

    const totalExpenses = cashTx
      .filter((t) => t.type === 'expense' || t.type === 'other_expense')
      .reduce((s, t) => s + t.amount, 0);

    const alreadyDistributed = transactions
      .filter((t) => t.type === 'profit_distribution')
      .reduce((s, t) => s + t.amount, 0);

    const reinvested = transactions
      .filter((t) => t.type === 'reinvestment')
      .reduce((s, t) => s + t.amount, 0);

    const netProfit = totalInterestCollected - totalExpenses;
    const availableToDistribute = netProfit - alreadyDistributed - reinvested;

    return {
      totalInterestCollected,
      totalExpenses,
      netProfit,
      alreadyDistributed,
      reinvested,
      availableToDistribute,
    };
  }, [payments, cashTx, transactions]);

  const partnerShares = useMemo(() => {
    return partners.map((p) => {
      const share = profitData.netProfit * (p.ownership_share / 100);
      const distributed = transactions
        .filter((t) => t.partner_id === p.id && t.type === 'profit_distribution')
        .reduce((s, t) => s + t.amount, 0);
      const withdrawn = transactions
        .filter((t) => t.partner_id === p.id && t.type === 'withdrawal')
        .reduce((s, t) => s + t.amount, 0);
      const reinvested = transactions
        .filter((t) => t.partner_id === p.id && t.type === 'reinvestment')
        .reduce((s, t) => s + t.amount, 0);
      return {
        ...p,
        share,
        distributed,
        withdrawn,
        reinvested,
        pending: share - distributed - withdrawn - reinvested,
      };
    });
  }, [partners, transactions, profitData.netProfit]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    const amount = parseFloat(form.amount);
    if (!amount || amount <= 0) { setError('El valor debe ser mayor a 0'); return; }
    if (!form.partner_id) { setError('Seleccione un socio'); return; }

    setSaving(true);

    const { data, error: err } = await supabase
      .from('partner_transactions')
      .insert({
        partner_id: form.partner_id,
        type: form.type,
        amount: Math.round(amount),
        description: form.description.trim() || null,
        transaction_date: form.transaction_date,
      })
      .select()
      .single();

    if (err) { setError(err.message); setSaving(false); return; }

    // If profit distribution, also register cash outflow
    if (form.type === 'profit_distribution') {
      await supabase.from('cash_transactions').insert({
        type: 'profit_distribution',
        amount: Math.round(amount),
        direction: 'out',
        description: `Distribución de utilidades a ${partners.find((p) => p.id === form.partner_id)?.name ?? ''}`,
        partner_id: form.partner_id,
        transaction_date: form.transaction_date,
      });
    }

    await logAudit('create', 'partner_transaction', data.id, { type: form.type, amount });

    setSaving(false);
    setModalOpen(false);
    setForm({ partner_id: '', type: 'profit_distribution', amount: '', description: '', transaction_date: todayISO() });
    refresh();
    refreshCash();
  }

  return (
    <div className="space-y-4">
      {/* Profit summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-gradient-to-br from-emerald-600 to-green-700 rounded-xl p-4 text-white">
          <PieChart className="mb-2 opacity-80" size={20} />
          <p className="text-xs text-green-100">Utilidad neta</p>
          <p className="text-xl font-bold">{formatCOP(profitData.netProfit)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Intereses cobrados</p>
          <p className="text-lg font-bold text-blue-700">{formatCOP(profitData.totalInterestCollected)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Gastos</p>
          <p className="text-lg font-bold text-red-600">{formatCOP(profitData.totalExpenses)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Disponible para distribuir</p>
          <p className="text-lg font-bold text-amber-600">{formatCOP(profitData.availableToDistribute)}</p>
        </div>
      </div>

      {/* Partner shares */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {partnerShares.map((p) => (
          <div key={p.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-700 rounded-full flex items-center justify-center text-white font-semibold">
                  {p.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">{p.name}</h3>
                  <p className="text-xs text-slate-500">{p.ownership_share}% participación</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-blue-50 rounded-lg p-3">
                <p className="text-xs text-blue-600">Corresponde (50%)</p>
                <p className="text-sm font-bold text-blue-700">{formatCOP(p.share)}</p>
              </div>
              <div className="bg-green-50 rounded-lg p-3">
                <p className="text-xs text-green-600">Distribuido</p>
                <p className="text-sm font-bold text-green-700">{formatCOP(p.distributed)}</p>
              </div>
              <div className="bg-slate-50 rounded-lg p-3">
                <p className="text-xs text-slate-500">Reinvertido</p>
                <p className="text-sm font-bold text-slate-700">{formatCOP(p.reinvested)}</p>
              </div>
              <div className="bg-amber-50 rounded-lg p-3">
                <p className="text-xs text-amber-600">Pendiente</p>
                <p className="text-sm font-bold text-amber-700">{formatCOP(p.pending)}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="flex gap-3">
        <button
          onClick={() => {
            setForm({ partner_id: '', type: 'profit_distribution', amount: '', description: '', transaction_date: todayISO() });
            setError(null);
            setModalOpen(true);
          }}
          className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
        >
          <Plus size={18} />
          Distribuir Utilidades
        </button>
        <button
          onClick={() => {
            setForm({ partner_id: '', type: 'reinvestment', amount: '', description: '', transaction_date: todayISO() });
            setError(null);
            setModalOpen(true);
          }}
          className="flex items-center gap-2 bg-slate-700 hover:bg-slate-800 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
        >
          <RotateCcw size={18} />
          Reinvertir
        </button>
      </div>

      {/* Distribution history */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h3 className="font-semibold text-slate-900">Historial de Distribuciones</h3>
        </div>
        <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
          {transactions.filter((t) => t.type === 'profit_distribution' || t.type === 'reinvestment').length === 0 ? (
            <p className="px-5 py-6 text-sm text-slate-400 text-center">No hay distribuciones registradas</p>
          ) : (
            transactions
              .filter((t) => t.type === 'profit_distribution' || t.type === 'reinvestment')
              .map((t) => {
                const partner = partners.find((p) => p.id === t.partner_id);
                return (
                  <div key={t.id} className="px-5 py-3 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-slate-800">
                        {t.type === 'profit_distribution' ? 'Distribución' : 'Reinversión'} - {partner?.name ?? 'Socio'}
                      </p>
                      <p className="text-xs text-slate-500">{formatDate(t.transaction_date)}{t.description ? ` · ${t.description}` : ''}</p>
                    </div>
                    <span className="text-sm font-semibold text-slate-700">{formatCOP(t.amount)}</span>
                  </div>
                );
              })
          )}
        </div>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={form.type === 'profit_distribution' ? 'Distribuir Utilidades' : 'Reinvertir'} size="md">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Socio *</label>
            <select
              value={form.partner_id}
              onChange={(e) => setForm({ ...form, partner_id: e.target.value })}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              required
            >
              <option value="">Seleccione socio</option>
              {partners.map((p) => (
                <option key={p.id} value={p.id}>{p.name} ({p.ownership_share}%)</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Valor (COP) *</label>
              <input
                type="number"
                step="any"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Fecha</label>
              <input
                type="date"
                value={form.transaction_date}
                onChange={(e) => setForm({ ...form, transaction_date: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Descripción</label>
            <input
              type="text"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
            />
          </div>
          {error && <div className="text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg p-3">{error}</div>}
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-medium disabled:opacity-50">
              {saving ? 'Guardando...' : 'Confirmar'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
