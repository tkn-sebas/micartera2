import { useState, FormEvent, useMemo, useEffect } from 'react';
import { useLoansWithClients, useClients, useInstallmentsForLoan } from '@/hooks/useData';
import { supabase } from '@/lib/supabase';
import { logAudit } from '@/lib/audit';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { generateSchedule, type ScheduleConfig } from '@/lib/schedule';
import { Modal, ConfirmModal } from '@/components/Modal';
import { HandCoins, Plus, Eye, Calendar, Clock } from 'lucide-react';
import type { Loan, LoanFrequency } from '@/types';

interface LoanFormState {
  client_id: string;
  capital: string;
  interest_rate: string;
  disbursement_date: string;
  term_days: string;
  frequency: LoanFrequency;
  collection_days: string[];
  exclude_sundays: boolean;
  exclude_holidays: boolean;
  custom_dates: string[];
  notes: string;
}

const EMPTY_FORM: LoanFormState = {
  client_id: '',
  capital: '',
  interest_rate: '',
  disbursement_date: todayISO(),
  term_days: '30',
  frequency: 'daily',
  collection_days: [],
  exclude_sundays: true,
  exclude_holidays: false,
  custom_dates: [],
  notes: '',
};

const DAY_OPTIONS = [
  { value: 'monday', label: 'Lunes' },
  { value: 'tuesday', label: 'Martes' },
  { value: 'wednesday', label: 'Miércoles' },
  { value: 'thursday', label: 'Jueves' },
  { value: 'friday', label: 'Viernes' },
  { value: 'saturday', label: 'Sábado' },
  { value: 'sunday', label: 'Domingo' },
];

export function Loans({ openNewLoan, newLoanSignal }: { openNewLoan?: boolean; newLoanSignal?: number }) {
  const { loans, loading, refresh } = useLoansWithClients();
  const { clients } = useClients();
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<LoanFormState>(EMPTY_FORM);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [detailLoan, setDetailLoan] = useState<Loan | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Open modal when signal changes
  useEffect(() => {
    if (newLoanSignal !== undefined && newLoanSignal > 0) {
      setForm(EMPTY_FORM);
      setError(null);
      setModalOpen(true);
    }
  }, [newLoanSignal]);

  const filtered = loans.filter((l) => {
    if (statusFilter === 'all') return true;
    return l.status === statusFilter;
  });

  // Preview schedule
  const previewSchedule = useMemo(() => {
    const capital = parseFloat(form.capital);
    const interestRate = parseFloat(form.interest_rate);
    const termDays = parseInt(form.term_days);
    if (!capital || !interestRate || !termDays || !form.client_id) return [];

    const config: ScheduleConfig = {
      capital,
      interestRate,
      disbursementDate: form.disbursement_date,
      termDays,
      frequency: form.frequency,
      collectionDays: form.collection_days,
      excludeSundays: form.exclude_sundays,
      excludeHolidays: form.exclude_holidays,
      customDates: form.custom_dates,
    };
    return generateSchedule(config);
  }, [form]);

  const interestAmount = parseFloat(form.capital) && parseFloat(form.interest_rate)
    ? (parseFloat(form.capital) * parseFloat(form.interest_rate)) / 100
    : 0;
  const totalToRecover = parseFloat(form.capital) ? parseFloat(form.capital) + interestAmount : 0;

  function toggleDay(day: string) {
    setForm((f) => ({
      ...f,
      collection_days: f.collection_days.includes(day)
        ? f.collection_days.filter((d) => d !== day)
        : [...f.collection_days, day],
    }));
  }

  function addCustomDate(date: string) {
    if (date && !form.custom_dates.includes(date)) {
      setForm((f) => ({ ...f, custom_dates: [...f.custom_dates, date].sort() }));
    }
  }

  function removeCustomDate(date: string) {
    setForm((f) => ({ ...f, custom_dates: f.custom_dates.filter((d) => d !== date) }));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    const capital = parseFloat(form.capital);
    const interestRate = parseFloat(form.interest_rate);
    const termDays = parseInt(form.term_days);

    if (!form.client_id) { setError('Seleccione un cliente'); return; }
    if (!capital || capital <= 0) { setError('El capital debe ser mayor a 0'); return; }
    if (isNaN(interestRate) || interestRate < 0) { setError('Porcentaje de interés inválido'); return; }
    if (!termDays || termDays <= 0) { setError('El plazo debe ser mayor a 0 días'); return; }
    if (form.frequency === 'custom_days' && form.collection_days.length === 0) {
      setError('Seleccione al menos un día de cobro'); return;
    }
    if (form.frequency === 'custom_dates' && form.custom_dates.length === 0) {
      setError('Agregue al menos una fecha personalizada'); return;
    }
    if (previewSchedule.length === 0) {
      setError('No se pudo generar el calendario. Verifique la configuración.'); return;
    }

    setSaving(true);

    const interestAmt = (capital * interestRate) / 100;
    const total = capital + interestAmt;
    const numInst = previewSchedule.length;
    const installmentAmt = previewSchedule[0]?.amount ?? 0;
    const lastInstallmentAmt = previewSchedule[numInst - 1]?.amount ?? 0;

    const { data: loanData, error: loanErr } = await supabase
      .from('loans')
      .insert({
        client_id: form.client_id,
        capital,
        interest_rate: interestRate,
        interest_amount: Math.round(interestAmt),
        total_to_recover: Math.round(total),
        disbursement_date: form.disbursement_date,
        term_days: termDays,
        frequency: form.frequency,
        collection_days: form.collection_days,
        exclude_sundays: form.exclude_sundays,
        exclude_holidays: form.exclude_holidays,
        custom_dates: form.custom_dates,
        num_installments: numInst,
        installment_amount: installmentAmt,
        last_installment_amount: lastInstallmentAmt,
        capital_pending: Math.round(capital),
        interest_pending: Math.round(interestAmt),
        notes: form.notes.trim() || null,
      })
      .select()
      .single();

    if (loanErr) { setError(loanErr.message); setSaving(false); return; }

    // Insert installments
    const installments = previewSchedule.map((inst) => ({
      loan_id: loanData.id,
      installment_number: inst.installment_number,
      due_date: inst.due_date,
      amount: inst.amount,
      capital_component: inst.capital_component,
      interest_component: inst.interest_component,
    }));

    const { error: instErr } = await supabase.from('installments').insert(installments);
    if (instErr) { setError(instErr.message); setSaving(false); return; }

    // Register cash outflow for disbursement
    await supabase.from('cash_transactions').insert({
      type: 'disbursement',
      amount: Math.round(capital),
      direction: 'out',
      description: `Desembolso de préstamo a ${clients.find((c) => c.id === form.client_id)?.full_name ?? ''}`,
      loan_id: loanData.id,
      transaction_date: form.disbursement_date,
    });

    await logAudit('create', 'loan', loanData.id, { capital, interest_rate: interestRate, term_days: termDays });

    setSaving(false);
    setModalOpen(false);
    setForm(EMPTY_FORM);
    refresh();
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
        >
          <option value="all">Todos los estados</option>
          <option value="active">Vigentes</option>
          <option value="completed">Completados</option>
          <option value="cancelled">Cancelados</option>
        </select>
        <button
          onClick={() => { setForm(EMPTY_FORM); setError(null); setModalOpen(true); }}
          className="flex items-center justify-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
        >
          <Plus size={18} />
          Nuevo Préstamo
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Cargando préstamos...</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <HandCoins className="mx-auto text-slate-300 mb-3" size={48} />
          <p className="text-slate-500">No hay préstamos registrados</p>
          <p className="text-slate-400 text-sm mt-1">Cree un préstamo para comenzar</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((loan) => {
            const pending = loan.capital_pending + loan.interest_pending;
            const progress = loan.total_to_recover > 0
              ? ((loan.total_to_recover - pending) / loan.total_to_recover) * 100
              : 0;
            return (
              <div key={loan.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <h3 className="font-semibold text-slate-900 truncate">{loan.client?.full_name ?? 'Cliente'}</h3>
                    <p className="text-xs text-slate-500">
                      CC: {loan.client?.id_number} · {formatDate(loan.disbursement_date)} · {loan.term_days} días
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      loan.status === 'active' ? 'bg-green-100 text-green-700' :
                      loan.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                      'bg-slate-100 text-slate-500'
                    }`}>
                      {loan.status === 'active' ? 'Vigente' : loan.status === 'completed' ? 'Completado' : 'Cancelado'}
                    </span>
                    <button
                      onClick={() => setDetailLoan(loan)}
                      className="flex items-center gap-1.5 py-1.5 px-3 text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                    >
                      <Eye size={15} /> Detalle
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-slate-500">Capital</p>
                    <p className="font-semibold text-slate-800">{formatCOP(loan.capital)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Interés ({loan.interest_rate}%)</p>
                    <p className="font-semibold text-slate-800">{formatCOP(loan.interest_amount)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Total</p>
                    <p className="font-semibold text-blue-700">{formatCOP(loan.total_to_recover)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Pagado</p>
                    <p className="font-semibold text-green-700">{formatCOP(loan.capital_paid + loan.interest_paid)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Pendiente</p>
                    <p className="font-semibold text-amber-600">{formatCOP(pending)}</p>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span>Progreso</span>
                    <span>{progress.toFixed(0)}%</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-600 to-green-500 rounded-full transition-all"
                      style={{ width: `${Math.min(progress, 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* New Loan Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Nuevo Préstamo"
        size="xl"
      >
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Client selection */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Cliente *</label>
            <select
              value={form.client_id}
              onChange={(e) => setForm({ ...form, client_id: e.target.value })}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              required
            >
              <option value="">Seleccione un cliente</option>
              {clients.filter((c) => c.active).map((c) => (
                <option key={c.id} value={c.id}>{c.full_name} - CC: {c.id_number}</option>
              ))}
            </select>
          </div>

          {/* Financial details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Capital (COP) *</label>
              <input
                type="number"
                step="any"
                value={form.capital}
                onChange={(e) => setForm({ ...form, capital: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                placeholder="500000"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Interés (%) *</label>
              <input
                type="number"
                step="any"
                value={form.interest_rate}
                onChange={(e) => setForm({ ...form, interest_rate: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                placeholder="20"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Plazo (días) *</label>
              <input
                type="number"
                value={form.term_days}
                onChange={(e) => setForm({ ...form, term_days: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                placeholder="30"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Fecha desembolso</label>
              <input
                type="date"
                value={form.disbursement_date}
                onChange={(e) => setForm({ ...form, disbursement_date: e.target.value })}
                className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                required
              />
            </div>
          </div>

          {/* Summary */}
          {interestAmount > 0 && (
            <div className="bg-blue-50 rounded-lg p-4 grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-xs text-slate-600">Interés total</p>
                <p className="text-sm font-bold text-slate-800">{formatCOP(interestAmount)}</p>
              </div>
              <div>
                <p className="text-xs text-slate-600">Total a recuperar</p>
                <p className="text-sm font-bold text-blue-700">{formatCOP(totalToRecover)}</p>
              </div>
              <div>
                <p className="text-xs text-slate-600">Cuotas generadas</p>
                <p className="text-sm font-bold text-green-700">{previewSchedule.length}</p>
              </div>
            </div>
          )}

          {/* Schedule config */}
          <div className="border-t border-slate-200 pt-4">
            <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
              <Calendar size={18} className="text-blue-600" /> Calendario de Cobro
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2 mb-3">
              {[
                { value: 'daily', label: 'Todos los días' },
                { value: 'weekly', label: 'Semanal' },
                { value: 'biweekly', label: 'Quincenal' },
                { value: 'monthly', label: 'Mensual' },
                { value: 'custom_days', label: 'Días específicos' },
              ].map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setForm({ ...form, frequency: opt.value as LoanFrequency })}
                  className={`px-3 py-2 rounded-lg text-sm font-medium border transition-colors ${
                    form.frequency === opt.value
                      ? 'bg-blue-700 text-white border-blue-700'
                      : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {form.frequency === 'custom_days' && (
              <div className="mb-3">
                <label className="block text-sm font-medium text-slate-700 mb-2">Días de cobro</label>
                <div className="flex flex-wrap gap-2">
                  {DAY_OPTIONS.map((day) => (
                    <button
                      key={day.value}
                      type="button"
                      onClick={() => toggleDay(day.value)}
                      className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition-colors ${
                        form.collection_days.includes(day.value)
                          ? 'bg-blue-700 text-white border-blue-700'
                          : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {day.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {form.frequency === 'custom_dates' && (
              <div className="mb-3">
                <label className="block text-sm font-medium text-slate-700 mb-2">Fechas personalizadas</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="date"
                    id="custom-date-input"
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const input = document.getElementById('custom-date-input') as HTMLInputElement;
                      if (input?.value) addCustomDate(input.value);
                      input.value = '';
                    }}
                    className="px-3 py-2 bg-blue-100 text-blue-700 rounded-lg font-medium hover:bg-blue-200"
                  >
                    Agregar
                  </button>
                </div>
                {form.custom_dates.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {form.custom_dates.map((d) => (
                      <span key={d} className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-lg text-sm">
                        {formatDate(d)}
                        <button type="button" onClick={() => removeCustomDate(d)} className="text-slate-400 hover:text-red-600">×</button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="flex flex-wrap gap-4">
              <label className="flex items-center gap-2 text-sm text-slate-700">
                <input
                  type="checkbox"
                  checked={form.exclude_sundays}
                  onChange={(e) => setForm({ ...form, exclude_sundays: e.target.checked })}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-600"
                />
                Excluir domingos
              </label>
              <label className="flex items-center gap-2 text-sm text-slate-700">
                <input
                  type="checkbox"
                  checked={form.exclude_holidays}
                  onChange={(e) => setForm({ ...form, exclude_holidays: e.target.checked })}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-600"
                />
                Excluir festivos
              </label>
            </div>
          </div>

          {/* Schedule preview */}
          {previewSchedule.length > 0 && (
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <div className="bg-slate-50 px-4 py-2 border-b border-slate-200">
                <h4 className="text-sm font-semibold text-slate-700">Vista previa del calendario ({previewSchedule.length} cuotas)</h4>
              </div>
              <div className="max-h-48 overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 sticky top-0">
                    <tr>
                      <th className="text-left px-4 py-2 font-medium text-slate-600">#</th>
                      <th className="text-left px-4 py-2 font-medium text-slate-600">Fecha</th>
                      <th className="text-right px-4 py-2 font-medium text-slate-600">Valor</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {previewSchedule.slice(0, 20).map((inst) => (
                      <tr key={inst.installment_number}>
                        <td className="px-4 py-1.5 text-slate-600">{inst.installment_number}</td>
                        <td className="px-4 py-1.5 text-slate-600">{formatDate(inst.due_date)}</td>
                        <td className="px-4 py-1.5 text-right font-medium text-slate-800">{formatCOP(inst.amount)}</td>
                      </tr>
                    ))}
                    {previewSchedule.length > 20 && (
                      <tr><td colSpan={3} className="px-4 py-2 text-center text-slate-400 text-xs">
                        ...y {previewSchedule.length - 20} cuotas más
                      </td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Observaciones</label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={2}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none resize-none"
            />
          </div>

          {error && <div className="text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg p-3">{error}</div>}

          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium">
              Cancelar
            </button>
            <button type="submit" disabled={saving} className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-medium disabled:opacity-50">
              {saving ? 'Creando...' : 'Crear Préstamo'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Loan Detail */}
      <LoanDetailModal loan={detailLoan} onClose={() => setDetailLoan(null)} />
    </div>
  );
}

function LoanDetailModal({ loan, onClose }: { loan: Loan | null; onClose: () => void }) {
  const { installments, loading } = useInstallmentsForLoan(loan?.id ?? null);

  if (!loan) return null;

  return (
    <Modal open={!!loan} onClose={onClose} title="Detalle del Préstamo" size="xl">
      <div className="space-y-5">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-slate-50 rounded-lg p-3">
            <p className="text-xs text-slate-500">Capital</p>
            <p className="text-sm font-bold text-slate-800">{formatCOP(loan.capital)}</p>
          </div>
          <div className="bg-slate-50 rounded-lg p-3">
            <p className="text-xs text-slate-500">Interés ({loan.interest_rate}%)</p>
            <p className="text-sm font-bold text-slate-800">{formatCOP(loan.interest_amount)}</p>
          </div>
          <div className="bg-slate-50 rounded-lg p-3">
            <p className="text-xs text-slate-500">Total a recuperar</p>
            <p className="text-sm font-bold text-blue-700">{formatCOP(loan.total_to_recover)}</p>
          </div>
          <div className="bg-slate-50 rounded-lg p-3">
            <p className="text-xs text-slate-500">Pendiente</p>
            <p className="text-sm font-bold text-amber-600">{formatCOP(loan.capital_pending + loan.interest_pending)}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
          <div>
            <p className="text-xs text-slate-500">Fecha desembolso</p>
            <p className="font-medium text-slate-700">{formatDate(loan.disbursement_date)}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Plazo</p>
            <p className="font-medium text-slate-700">{loan.term_days} días</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Frecuencia</p>
            <p className="font-medium text-slate-700 capitalize">{loan.frequency}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Cuotas</p>
            <p className="font-medium text-slate-700">{loan.num_installments}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-green-50 rounded-lg p-3">
            <p className="text-xs text-green-600">Capital recuperado</p>
            <p className="text-sm font-bold text-green-700">{formatCOP(loan.capital_paid)}</p>
          </div>
          <div className="bg-blue-50 rounded-lg p-3">
            <p className="text-xs text-blue-600">Utilidad por intereses</p>
            <p className="text-sm font-bold text-blue-700">{formatCOP(loan.interest_paid)}</p>
          </div>
        </div>

        {loan.notes && (
          <div className="bg-slate-50 rounded-lg p-3">
            <p className="text-xs text-slate-500 mb-1">Observaciones</p>
            <p className="text-sm text-slate-700 italic">"{loan.notes}"</p>
          </div>
        )}

        <div>
          <h4 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
            <Clock size={18} className="text-blue-600" /> Calendario de Cuotas
          </h4>
          {loading ? (
            <p className="text-sm text-slate-400">Cargando...</p>
          ) : (
            <div className="max-h-64 overflow-y-auto border border-slate-200 rounded-lg">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 sticky top-0">
                  <tr>
                    <th className="text-left px-4 py-2 font-medium text-slate-600">#</th>
                    <th className="text-left px-4 py-2 font-medium text-slate-600">Vencimiento</th>
                    <th className="text-right px-4 py-2 font-medium text-slate-600">Cuota</th>
                    <th className="text-right px-4 py-2 font-medium text-slate-600">Pagado</th>
                    <th className="text-center px-4 py-2 font-medium text-slate-600">Estado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {installments.map((inst) => (
                    <tr key={inst.id} className={inst.status === 'overdue' ? 'bg-red-50' : ''}>
                      <td className="px-4 py-2 text-slate-600">{inst.installment_number}</td>
                      <td className="px-4 py-2 text-slate-600">{formatDate(inst.due_date)}</td>
                      <td className="px-4 py-2 text-right font-medium text-slate-800">{formatCOP(inst.amount)}</td>
                      <td className="px-4 py-2 text-right text-green-700">{formatCOP(inst.amount_paid)}</td>
                      <td className="px-4 py-2 text-center">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          inst.status === 'paid' ? 'bg-green-100 text-green-700' :
                          inst.status === 'partial' ? 'bg-amber-100 text-amber-700' :
                          inst.status === 'overdue' ? 'bg-red-100 text-red-700' :
                          'bg-slate-100 text-slate-500'
                        }`}>
                          {inst.status === 'paid' ? 'Pagada' : inst.status === 'partial' ? 'Parcial' : inst.status === 'overdue' ? 'Vencida' : 'Pendiente'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}
