import { useMemo } from 'react';
import { useInstallments, useLoans, useClients } from '@/hooks/useData';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { getOverdueDays } from '@/lib/schedule';
import { AlertTriangle, Calendar } from 'lucide-react';

export function Mora() {
  const { installments } = useInstallments();
  const { loans } = useLoans();
  const { clients } = useClients();

  const moraData = useMemo(() => {
    const today = todayISO();
    const overdue = installments.filter(
      (i) => (i.status === 'pending' || i.status === 'partial') && i.due_date < today
    );

    const byLoan: Record<string, {
      loanId: string;
      clientId: string;
      clientName: string;
      overdueInstallments: typeof overdue;
      totalOverdue: number;
      firstOverdueDate: string;
      maxDays: number;
    }> = {};

    for (const inst of overdue) {
      const loan = loans.find((l) => l.id === inst.loan_id);
      if (!loan || loan.status !== 'active') continue;
      const client = clients.find((c) => c.id === loan.client_id);
      const loanId = inst.loan_id;

      if (!byLoan[loanId]) {
        byLoan[loanId] = {
          loanId,
          clientId: loan.client_id,
          clientName: client?.full_name ?? 'Cliente',
          overdueInstallments: [],
          totalOverdue: 0,
          firstOverdueDate: inst.due_date,
          maxDays: 0,
        };
      }

      byLoan[loanId].overdueInstallments.push(inst);
      byLoan[loanId].totalOverdue += inst.amount - inst.amount_paid;
      if (inst.due_date < byLoan[loanId].firstOverdueDate) {
        byLoan[loanId].firstOverdueDate = inst.due_date;
      }

      const loan2 = loans.find((l) => l.id === loanId);
      const days = getOverdueDays(inst.due_date, loan2?.exclude_sundays ?? true);
      if (days > byLoan[loanId].maxDays) byLoan[loanId].maxDays = days;
    }

    const list = Object.values(byLoan).sort((a, b) => a.firstOverdueDate.localeCompare(b.firstOverdueDate));

    const totalOverdueAmount = list.reduce((s, l) => s + l.totalOverdue, 0);
    const clientsInMora = list.length;

    return { list, totalOverdueAmount, clientsInMora, totalOverdueInstallments: overdue.length };
  }, [installments, loans, clients]);

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Clientes en mora</p>
          <p className="text-2xl font-bold text-red-600">{moraData.clientsInMora}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Cuotas vencidas</p>
          <p className="text-2xl font-bold text-red-600">{moraData.totalOverdueInstallments}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Total vencido</p>
          <p className="text-2xl font-bold text-red-600">{formatCOP(moraData.totalOverdueAmount)}</p>
        </div>
      </div>

      {moraData.list.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <AlertTriangle className="mx-auto text-green-300 mb-3" size={48} />
          <p className="text-green-600 font-medium">No hay clientes en mora</p>
          <p className="text-slate-400 text-sm mt-1">Todos los pagos están al día</p>
        </div>
      ) : (
        <div className="space-y-3">
          {moraData.list.map((item) => {
            const loan = loans.find((l) => l.id === item.loanId);
            return (
              <div key={item.loanId} className="bg-white rounded-xl shadow-sm border border-red-200 p-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                  <div>
                    <h3 className="font-semibold text-slate-900">{item.clientName}</h3>
                    <p className="text-xs text-slate-500">
                      Capital: {loan ? formatCOP(loan.capital) : ''} · Tasa: {loan?.interest_rate}%
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-xs px-3 py-1 rounded-full bg-red-100 text-red-700 font-medium">
                      {item.maxDays} días de mora
                    </span>
                    <span className="text-xs px-3 py-1 rounded-full bg-amber-100 text-amber-700 font-medium">
                      {item.overdueInstallments.length} cuotas vencidas
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="bg-red-50 rounded-lg p-3">
                    <p className="text-xs text-red-500">Saldo vencido</p>
                    <p className="text-lg font-bold text-red-700">{formatCOP(item.totalOverdue)}</p>
                  </div>
                  <div className="bg-amber-50 rounded-lg p-3">
                    <p className="text-xs text-amber-600">Primer vencimiento</p>
                    <p className="text-sm font-bold text-amber-700">{formatDate(item.firstOverdueDate)}</p>
                  </div>
                </div>

                <div className="border border-slate-100 rounded-lg overflow-hidden">
                  <div className="max-h-40 overflow-y-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-slate-50 sticky top-0">
                        <tr>
                          <th className="text-left px-3 py-2 font-medium text-slate-600">#</th>
                          <th className="text-left px-3 py-2 font-medium text-slate-600">Vencimiento</th>
                          <th className="text-right px-3 py-2 font-medium text-slate-600">Cuota</th>
                          <th className="text-right px-3 py-2 font-medium text-slate-600">Pendiente</th>
                          <th className="text-center px-3 py-2 font-medium text-slate-600">Días</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {item.overdueInstallments.map((inst) => {
                          const days = getOverdueDays(inst.due_date, loan?.exclude_sundays ?? true);
                          return (
                            <tr key={inst.id}>
                              <td className="px-3 py-2 text-slate-600">{inst.installment_number}</td>
                              <td className="px-3 py-2 text-slate-600">{formatDate(inst.due_date)}</td>
                              <td className="px-3 py-2 text-right text-slate-700">{formatCOP(inst.amount)}</td>
                              <td className="px-3 py-2 text-right font-semibold text-red-600">{formatCOP(inst.amount - inst.amount_paid)}</td>
                              <td className="px-3 py-2 text-center text-red-500 font-medium">{days}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-2 text-xs text-slate-400">
                  <Calendar size={14} />
                  Días calculados según el calendario del préstamo (excluyendo domingos/festivos si aplica)
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
