import { useState, FormEvent, useMemo } from 'react';
import { usePaymentsWithDetails, useLoansWithClients, useInstallmentsForLoan } from '@/hooks/useData';
import { supabase } from '@/lib/supabase';
import { logAudit } from '@/lib/audit';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { Modal, ConfirmModal } from '@/components/Modal';
import { Banknote, Plus, RotateCcw, Search } from 'lucide-react';
import type { Payment, PaymentMethod } from '@/types';

export function Payments() {
  const { payments, loading, refresh } = usePaymentsWithDetails();
  const { loans } = useLoansWithClients();
  const [modalOpen, setModalOpen] = useState(false);
  const [reversePayment, setReversePayment] = useState<Payment | null>(null);
  const [reverseReason, setReverseReason] = useState('');
  const [search, setSearch] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const filtered = payments.filter((p) => {
    const q = search.toLowerCase();
    return (
      p.client?.full_name?.toLowerCase().includes(q) ||
      String(p.amount).includes(q)
    );
  });

  const totalCollected = payments
    .filter((p) => !p.is_reversed)
    .reduce((s, p) => s + p.amount, 0);
  const totalCapital = payments
    .filter((p) => !p.is_reversed)
    .reduce((s, p) => s + p.capital_applied, 0);
  const totalInterest = payments
    .filter((p) => !p.is_reversed)
    .reduce((s, p) => s + p.interest_applied, 0);

  async function handleReverse() {
    if (!reversePayment) return;
    if (!reverseReason.trim()) { setError('El motivo es obligatorio'); return; }

    setSaving(true);
    setError(null);

    // Mark payment as reversed
    const { error: payErr } = await supabase
      .from('payments')
      .update({ is_reversed: true, reversed_at: new Date().toISOString() })
      .eq('id', reversePayment.id);

    if (payErr) { setError(payErr.message); setSaving(false); return; }

    // Insert reversal record
    await supabase.from('payment_reversals').insert({
      payment_id: reversePayment.id,
      reason: reverseReason.trim(),
    });

    // Reverse installment payment
    if (reversePayment.installment_id) {
      const { data: inst } = await supabase
        .from('installments')
        .select('*')
        .eq('id', reversePayment.installment_id)
        .maybeSingle();

      if (inst) {
        const newAmountPaid = Math.max(0, inst.amount_paid - reversePayment.amount);
        const newStatus = newAmountPaid <= 0 ? 'pending' : 'partial';
        await supabase
          .from('installments')
          .update({ amount_paid: newAmountPaid, status: newStatus })
          .eq('id', inst.id);
      }
    }

    // Reverse loan totals
    const { data: loan } = await supabase
      .from('loans')
      .select('*')
      .eq('id', reversePayment.loan_id)
      .maybeSingle();

    if (loan) {
      await supabase
        .from('loans')
        .update({
          capital_paid: Math.max(0, loan.capital_paid - reversePayment.capital_applied),
          interest_paid: Math.max(0, loan.interest_paid - reversePayment.interest_applied),
          capital_pending: loan.capital_pending + reversePayment.capital_applied,
          interest_pending: loan.interest_pending + reversePayment.interest_applied,
        })
        .eq('id', loan.id);
    }

    // Reverse cash transaction
    await supabase.from('cash_transactions').insert({
      type: 'other_expense',
      amount: reversePayment.amount,
      direction: 'out',
      description: `Reversión de pago - ${reverseReason.trim()}`,
      payment_id: reversePayment.id,
      transaction_date: todayISO(),
    });

    await logAudit('reverse', 'payment', reversePayment.id, { reason: reverseReason });

    setSaving(false);
    setReversePayment(null);
    setReverseReason('');
    refresh();
  }

  return (
    <div className="space-y-4">
      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Total cobrado</p>
          <p className="text-xl font-bold text-green-600">{formatCOP(totalCollected)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Capital recuperado</p>
          <p className="text-xl font-bold text-blue-700">{formatCOP(totalCapital)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Utilidad por intereses</p>
          <p className="text-xl font-bold text-emerald-600">{formatCOP(totalInterest)}</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por cliente o valor..."
            className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
          />
        </div>
        <button
          onClick={() => { setModalOpen(true); setError(null); }}
          className="flex items-center justify-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
        >
          <Plus size={18} />
          Registrar Pago
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Cargando pagos...</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Banknote className="mx-auto text-slate-300 mb-3" size={48} />
          <p className="text-slate-500">No hay pagos registrados</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left px-4 py-3 font-medium text-slate-600">Fecha</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-600">Cliente</th>
                  <th className="text-right px-4 py-3 font-medium text-slate-600">Valor</th>
                  <th className="text-right px-4 py-3 font-medium text-slate-600">Capital</th>
                  <th className="text-right px-4 py-3 font-medium text-slate-600">Interés</th>
                  <th className="text-center px-4 py-3 font-medium text-slate-600">Método</th>
                  <th className="text-center px-4 py-3 font-medium text-slate-600">Estado</th>
                  <th className="text-center px-4 py-3 font-medium text-slate-600">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((p) => (
                  <tr key={p.id} className={p.is_reversed ? 'opacity-50' : ''}>
                    <td className="px-4 py-3 text-slate-600 whitespace-nowrap">{formatDate(p.payment_date)}</td>
                    <td className="px-4 py-3 text-slate-800 font-medium">{p.client?.full_name ?? 'N/A'}</td>
                    <td className="px-4 py-3 text-right font-semibold text-slate-800">{formatCOP(p.amount)}</td>
                    <td className="px-4 py-3 text-right text-blue-700">{formatCOP(p.capital_applied)}</td>
                    <td className="px-4 py-3 text-right text-emerald-600">{formatCOP(p.interest_applied)}</td>
                    <td className="px-4 py-3 text-center text-slate-500 capitalize">{p.payment_method === 'cash' ? 'Efectivo' : p.payment_method === 'transfer' ? 'Transferencia' : 'Otro'}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        p.is_reversed ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                      }`}>
                        {p.is_reversed ? 'Revertido' : 'Activo'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {!p.is_reversed && (
                        <button
                          onClick={() => { setReversePayment(p); setReverseReason(''); setError(null); }}
                          className="text-red-500 hover:text-red-700 p-1"
                          title="Revertir pago"
                        >
                          <RotateCcw size={16} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Register Payment Modal */}
      <RegisterPaymentModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        loans={loans}
        onSuccess={refresh}
      />

      {/* Reversal Modal */}
      <Modal
        open={!!reversePayment}
        onClose={() => setReversePayment(null)}
        title="Revertir Pago"
        size="sm"
      >
        <div className="space-y-4">
          {reversePayment && (
            <div className="bg-slate-50 rounded-lg p-3 text-sm">
              <p><span className="text-slate-500">Valor:</span> <span className="font-semibold">{formatCOP(reversePayment.amount)}</span></p>
              <p><span className="text-slate-500">Fecha:</span> {formatDate(reversePayment.payment_date)}</p>
              <p className="text-xs text-slate-400 mt-1">El pago original se conserva. Se registra el motivo, usuario y fecha.</p>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Motivo de la reversión *</label>
            <textarea
              value={reverseReason}
              onChange={(e) => setReverseReason(e.target.value)}
              rows={3}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none resize-none"
              placeholder="Describa el motivo de la reversión..."
            />
          </div>
          {error && <div className="text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg p-3">{error}</div>}
          <div className="flex justify-end gap-3">
            <button onClick={() => setReversePayment(null)} className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium">
              Cancelar
            </button>
            <button onClick={handleReverse} disabled={saving} className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium disabled:opacity-50">
              {saving ? 'Revirtiendo...' : 'Revertir Pago'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

interface RegisterPaymentModalProps {
  open: boolean;
  onClose: () => void;
  loans: ReturnType<typeof useLoansWithClients>['loans'];
  onSuccess: () => void;
}

function RegisterPaymentModal({ open, onClose, loans, onSuccess }: RegisterPaymentModalProps) {
  const [loanId, setLoanId] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentDate, setPaymentDate] = useState(todayISO());
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const { installments, refresh: refreshInst } = useInstallmentsForLoan(loanId || null);

  const selectedLoan = loans.find((l) => l.id === loanId);
  const activeLoans = loans.filter((l) => l.status === 'active');

  const paymentBreakdown = useMemo(() => {
    if (!selectedLoan || !amount) return null;
    const payAmount = parseFloat(amount);
    if (!payAmount || payAmount <= 0) return null;

    // Apply interest first, then capital
    const interestToPay = Math.min(payAmount, selectedLoan.interest_pending);
    const capitalToPay = Math.min(payAmount - interestToPay, selectedLoan.capital_pending);

    return { interestToPay, capitalToPay, total: payAmount };
  }, [selectedLoan, amount]);

  function reset() {
    setLoanId('');
    setAmount('');
    setPaymentDate(todayISO());
    setPaymentMethod('cash');
    setNotes('');
    setError(null);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!loanId) { setError('Seleccione un préstamo'); return; }
    const payAmount = parseFloat(amount);
    if (!payAmount || payAmount <= 0) { setError('El valor del pago debe ser mayor a 0'); return; }
    if (!selectedLoan) { setError('Préstamo no encontrado'); return; }

    const totalPending = selectedLoan.capital_pending + selectedLoan.interest_pending;
    if (payAmount > totalPending + 1) {
      setError(`El pago excede el saldo pendiente (${formatCOP(totalPending)})`); return;
    }

    setSaving(true);

    const interestApplied = Math.min(payAmount, selectedLoan.interest_pending);
    const capitalApplied = Math.min(payAmount - interestApplied, selectedLoan.capital_pending);

    // Find the installment to apply this payment to
    // Prioritize overdue, then earliest pending/partial
    const today = todayISO();
    const sortedInst = [...installments].sort((a, b) => {
      const aOverdue = a.due_date < today && a.status !== 'paid' ? 0 : 1;
      const bOverdue = b.due_date < today && b.status !== 'paid' ? 0 : 1;
      if (aOverdue !== bOverdue) return aOverdue - bOverdue;
      return a.due_date.localeCompare(b.due_date);
    });

    let remainingAmount = payAmount;
    let appliedInstallmentId: string | null = null;

    // Distribute payment across installments
    for (const inst of sortedInst) {
      if (remainingAmount <= 0) break;
      if (inst.status === 'paid') continue;

      const instPending = inst.amount - inst.amount_paid;
      if (instPending <= 0) continue;

      const appliedToThis = Math.min(remainingAmount, instPending);
      const newAmountPaid = inst.amount_paid + appliedToThis;
      const newStatus = newAmountPaid >= inst.amount ? 'paid' : 'partial';

      await supabase
        .from('installments')
        .update({ amount_paid: newAmountPaid, status: newStatus })
        .eq('id', inst.id);

      if (!appliedInstallmentId) appliedInstallmentId = inst.id;
      remainingAmount -= appliedToThis;
    }

    refreshInst();

    // Insert payment record
    const { data: payData, error: payErr } = await supabase
      .from('payments')
      .insert({
        loan_id: loanId,
        client_id: selectedLoan.client_id,
        installment_id: appliedInstallmentId,
        amount: Math.round(payAmount),
        capital_applied: Math.round(capitalApplied),
        interest_applied: Math.round(interestApplied),
        payment_date: paymentDate,
        payment_method: paymentMethod,
        notes: notes.trim() || null,
      })
      .select()
      .single();

    if (payErr) { setError(payErr.message); setSaving(false); return; }

    // Update loan totals
    const newCapitalPaid = selectedLoan.capital_paid + capitalApplied;
    const newInterestPaid = selectedLoan.interest_paid + interestApplied;
    const newCapitalPending = selectedLoan.capital_pending - capitalApplied;
    const newInterestPending = selectedLoan.interest_pending - interestApplied;
    const newStatus = (newCapitalPending + newInterestPending) <= 1 ? 'completed' : 'active';

    await supabase
      .from('loans')
      .update({
        capital_paid: newCapitalPaid,
        interest_paid: newInterestPaid,
        capital_pending: newCapitalPending,
        interest_pending: newInterestPending,
        status: newStatus,
      })
      .eq('id', loanId);

    // Register cash inflow
    await supabase.from('cash_transactions').insert({
      type: 'payment_received',
      amount: Math.round(payAmount),
      direction: 'in',
      description: `Pago de ${selectedLoan.client?.full_name ?? ''}`,
      loan_id: loanId,
      payment_id: payData.id,
      transaction_date: paymentDate,
    });

    await logAudit('create', 'payment', payData.id, { amount: payAmount, loan_id: loanId });

    setSaving(false);
    reset();
    onClose();
    onSuccess();
  }

  return (
    <Modal open={open} onClose={() => { reset(); onClose(); }} title="Registrar Pago" size="md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Préstamo *</label>
          <select
            value={loanId}
            onChange={(e) => setLoanId(e.target.value)}
            className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
            required
          >
            <option value="">Seleccione un préstamo</option>
            {activeLoans.map((l) => (
              <option key={l.id} value={l.id}>
                {l.client?.full_name} - {formatCOP(l.capital)} ({formatDate(l.disbursement_date)})
              </option>
            ))}
          </select>
        </div>

        {selectedLoan && (
          <div className="bg-slate-50 rounded-lg p-3 space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">Capital pendiente:</span>
              <span className="font-medium text-slate-700">{formatCOP(selectedLoan.capital_pending)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Intereses pendientes:</span>
              <span className="font-medium text-slate-700">{formatCOP(selectedLoan.interest_pending)}</span>
            </div>
            <div className="flex justify-between border-t border-slate-200 pt-1 mt-1">
              <span className="text-slate-600 font-medium">Total pendiente:</span>
              <span className="font-bold text-amber-600">{formatCOP(selectedLoan.capital_pending + selectedLoan.interest_pending)}</span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Valor del pago (COP) *</label>
            <input
              type="number"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              placeholder="50000"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Fecha</label>
            <input
              type="date"
              value={paymentDate}
              onChange={(e) => setPaymentDate(e.target.value)}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Método de pago</label>
          <div className="flex gap-2">
            {[
              { value: 'cash', label: 'Efectivo' },
              { value: 'transfer', label: 'Transferencia' },
              { value: 'other', label: 'Otro' },
            ].map((m) => (
              <button
                key={m.value}
                type="button"
                onClick={() => setPaymentMethod(m.value as PaymentMethod)}
                className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium border transition-colors ${
                  paymentMethod === m.value
                    ? 'bg-blue-700 text-white border-blue-700'
                    : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {paymentBreakdown && (
          <div className="bg-blue-50 rounded-lg p-3 space-y-1 text-sm">
            <p className="text-xs text-slate-500 mb-1">Distribución del pago (intereses primero):</p>
            <div className="flex justify-between">
              <span className="text-emerald-700">A intereses:</span>
              <span className="font-medium">{formatCOP(paymentBreakdown.interestToPay)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-blue-700">A capital:</span>
              <span className="font-medium">{formatCOP(paymentBreakdown.capitalToPay)}</span>
            </div>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Observaciones</label>
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
          />
        </div>

        {error && <div className="text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg p-3">{error}</div>}

        <div className="flex justify-end gap-3 pt-2">
          <button type="button" onClick={() => { reset(); onClose(); }} className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium">
            Cancelar
          </button>
          <button type="submit" disabled={saving} className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-medium disabled:opacity-50">
            {saving ? 'Guardando...' : 'Registrar Pago'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
