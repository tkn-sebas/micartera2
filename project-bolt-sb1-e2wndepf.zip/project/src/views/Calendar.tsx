import { useState, useMemo } from 'react';
import { useInstallments, useLoans, useClients } from '@/hooks/useData';
import { formatCOP, formatDate, todayISO } from '@/lib/format';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';

const MONTH_NAMES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

const WEEKDAY_NAMES = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

export function CalendarView() {
  const { installments } = useInstallments();
  const { loans } = useLoans();
  const { clients } = useClients();
  const [currentDate, setCurrentDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const installmentsByDate = useMemo(() => {
    const map: Record<string, typeof installments> = {};
    for (const inst of installments) {
      if (!map[inst.due_date]) map[inst.due_date] = [];
      map[inst.due_date].push(inst);
    }
    return map;
  }, [installments]);

  const calendarDays = useMemo(() => {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDayOfWeek = firstDay.getDay();
    const daysInMonth = lastDay.getDate();

    const days: (Date | null)[] = [];
    for (let i = 0; i < startDayOfWeek; i++) days.push(null);
    for (let d = 1; d <= daysInMonth; d++) days.push(new Date(year, month, d));
    return days;
  }, [year, month]);

  const today = todayISO();

  // Monthly summary
  const monthInstallments = installments.filter((i) => {
    const d = new Date(i.due_date);
    return d.getFullYear() === year && d.getMonth() === month;
  });

  const monthTotal = monthInstallments.reduce((s, i) => s + i.amount, 0);
  const monthPending = monthInstallments
    .filter((i) => i.status !== 'paid')
    .reduce((s, i) => s + (i.amount - i.amount_paid), 0);
  const monthCollected = monthInstallments.reduce((s, i) => s + i.amount_paid, 0);

  function getLoanClient(installmentLoanId: string) {
    const loan = loans.find((l) => l.id === installmentLoanId);
    const client = loan ? clients.find((c) => c.id === loan.client_id) : null;
    return client?.full_name ?? 'Cliente';
  }

  return (
    <div className="space-y-4">
      {/* Monthly summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Total cuotas del mes</p>
          <p className="text-xl font-bold text-slate-800">{formatCOP(monthTotal)}</p>
          <p className="text-xs text-slate-400 mt-1">{monthInstallments.length} cuotas</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Pendiente por cobrar</p>
          <p className="text-xl font-bold text-amber-600">{formatCOP(monthPending)}</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <p className="text-xs text-slate-500">Cobrado en el mes</p>
          <p className="text-xl font-bold text-green-600">{formatCOP(monthCollected)}</p>
        </div>
      </div>

      {/* Calendar */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <h3 className="font-semibold text-slate-900 flex items-center gap-2">
            <CalendarIcon size={20} className="text-blue-600" />
            {MONTH_NAMES[month]} {year}
          </h3>
          <div className="flex gap-2">
            <button
              onClick={() => setCurrentDate(new Date(year, month - 1, 1))}
              className="p-2 rounded-lg hover:bg-slate-100 text-slate-600"
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={() => setCurrentDate(new Date())}
              className="px-3 py-1.5 rounded-lg text-sm font-medium text-blue-700 bg-blue-50 hover:bg-blue-100"
            >
              Hoy
            </button>
            <button
              onClick={() => setCurrentDate(new Date(year, month + 1, 1))}
              className="p-2 rounded-lg hover:bg-slate-100 text-slate-600"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>

        <div className="p-3">
          {/* Weekday headers */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {WEEKDAY_NAMES.map((day) => (
              <div key={day} className="text-center text-xs font-medium text-slate-400 py-1">{day}</div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, idx) => {
              if (!day) return <div key={idx} className="aspect-square" />;
              const dateStr = day.toISOString().split('T')[0];
              const dayInst = installmentsByDate[dateStr] ?? [];
              const isToday = dateStr === today;
              const isPast = dateStr < today;
              const dayTotal = dayInst.reduce((s, i) => s + (i.amount - i.amount_paid), 0);
              const hasOverdue = dayInst.some((i) => i.status !== 'paid' && isPast);
              const allPaid = dayInst.length > 0 && dayInst.every((i) => i.status === 'paid');

              return (
                <div
                  key={idx}
                  className={`aspect-square border rounded-lg p-1 text-xs flex flex-col ${
                    isToday ? 'border-blue-600 border-2' : 'border-slate-100'
                  } ${allPaid ? 'bg-green-50' : hasOverdue ? 'bg-red-50' : 'bg-white'}`}
                >
                  <span className={`font-medium ${isToday ? 'text-blue-700' : 'text-slate-600'}`}>
                    {day.getDate()}
                  </span>
                  {dayInst.length > 0 && (
                    <div className="mt-auto">
                      <p className={`font-semibold truncate ${
                        allPaid ? 'text-green-600' : hasOverdue ? 'text-red-600' : 'text-slate-700'
                      }`}>
                        {formatCOP(dayTotal)}
                      </p>
                      <p className="text-slate-400 text-[10px]">{dayInst.length} cuota{dayInst.length > 1 ? 's' : ''}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Day detail list */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200">
          <h3 className="font-semibold text-slate-900">Cuotas de {MONTH_NAMES[month]} {year}</h3>
        </div>
        <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
          {monthInstallments.length === 0 ? (
            <p className="px-5 py-6 text-sm text-slate-400 text-center">No hay cuotas programadas este mes</p>
          ) : (
            monthInstallments
              .sort((a, b) => a.due_date.localeCompare(b.due_date))
              .map((inst) => {
                const loan = loans.find((l) => l.id === inst.loan_id);
                const isOverdue = inst.due_date < today && inst.status !== 'paid';
                return (
                  <div key={inst.id} className="px-5 py-3 flex items-center justify-between">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-800 truncate">
                        {getLoanClient(inst.loan_id)}
                      </p>
                      <p className="text-xs text-slate-500">
                        Cuota #{inst.installment_number} · {formatDate(inst.due_date)}
                        {loan && ` · ${loan.interest_rate}% interés`}
                      </p>
                    </div>
                    <div className="text-right ml-2 whitespace-nowrap">
                      <p className="text-sm font-semibold text-slate-700">{formatCOP(inst.amount)}</p>
                      <p className={`text-xs ${isOverdue ? 'text-red-500' : 'text-slate-400'}`}>
                        {inst.status === 'paid' ? 'Pagada' : isOverdue ? 'Vencida' : formatCOP(inst.amount_paid) + ' pagado'}
                      </p>
                    </div>
                  </div>
                );
              })
          )}
        </div>
      </div>
    </div>
  );
}
