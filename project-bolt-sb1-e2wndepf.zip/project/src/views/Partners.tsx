import { useMemo, useState, FormEvent } from 'react';
import { usePartners, usePartnerTransactions } from '@/hooks/useData';
import { formatCOP, formatDate } from '@/lib/format';
import { UserCircle2, TrendingUp, TrendingDown, Wallet, UserPlus, Mail, Lock, User } from 'lucide-react';
import { Modal } from '@/components/Modal';
import { supabase } from '@/lib/supabase';
import { BiometricSecurity } from '@/components/BiometricSecurity';

const TX_LABELS: Record<string, string> = {
  contribution: 'Aporte',
  withdrawal: 'Retiro',
  profit_distribution: 'Ganancia distribuida',
  reinvestment: 'Reinversión',
};

export function Partners() {
  const { partners, loading, refresh } = usePartners();
  const { transactions } = usePartnerTransactions();
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteForm, setInviteForm] = useState({ name: '', email: '', password: '' });
  const [inviteError, setInviteError] = useState<string | null>(null);
  const [inviteSuccess, setInviteSuccess] = useState<string | null>(null);
  const [inviting, setInviting] = useState(false);

  const canInvite = partners.length < 2;

  const partnerData = useMemo(() => {
    return partners.map((p) => {
      const pTx = transactions.filter((t) => t.partner_id === p.id);
      const contributions = pTx.filter((t) => t.type === 'contribution').reduce((s, t) => s + t.amount, 0);
      const withdrawals = pTx.filter((t) => t.type === 'withdrawal').reduce((s, t) => s + t.amount, 0);
      const profits = pTx.filter((t) => t.type === 'profit_distribution').reduce((s, t) => s + t.amount, 0);
      const reinvestments = pTx.filter((t) => t.type === 'reinvestment').reduce((s, t) => s + t.amount, 0);
      const balance = contributions + profits + reinvestments - withdrawals;
      return { ...p, transactions: pTx, contributions, withdrawals, profits, reinvestments, balance };
    });
  }, [partners, transactions]);

  async function handleInvite(e: FormEvent) {
    e.preventDefault();
    setInviteError(null);
    setInviteSuccess(null);

    if (inviteForm.name.trim().length < 2) {
      setInviteError('Ingrese el nombre completo del socio');
      return;
    }
    if (inviteForm.password.length < 6) {
      setInviteError('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    setInviting(true);

    const { data: sessionData } = await supabase.auth.getSession();
    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/invite-partner`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionData.session?.access_token}`,
          'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
        },
        body: JSON.stringify({
          email: inviteForm.email,
          password: inviteForm.password,
          name: inviteForm.name,
        }),
      }
    );

    const result = await response.json();

    if (!response.ok) {
      setInviteError(result.error ?? 'Error al invitar socio');
      setInviting(false);
      return;
    }

    setInviteSuccess(`Socio ${inviteForm.name} creado exitosamente. Puede iniciar sesión con su correo y contraseña.`);
    setInviteForm({ name: '', email: '', password: '' });
    setInviting(false);
    refresh();
    setTimeout(() => {
      setInviteOpen(false);
      setInviteSuccess(null);
    }, 3000);
  }

  return (
    <div className="space-y-4">
      {canInvite && (
        <div className="flex justify-end">
          <button
            onClick={() => { setInviteOpen(true); setInviteError(null); setInviteSuccess(null); }}
            className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2.5 rounded-lg font-medium transition-colors"
          >
            <UserPlus size={18} />
            Invitar Socio
          </button>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12 text-slate-400">Cargando socios...</div>
      ) : partnerData.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <UserCircle2 className="mx-auto text-slate-300 mb-3" size={48} />
          <p className="text-slate-500">No hay socios registrados</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {partnerData.map((p) => (
            <div key={p.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-blue-700 rounded-full flex items-center justify-center text-white text-lg font-semibold">
                  {p.name.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-900">{p.name}</h3>
                  <p className="text-xs text-slate-500">{p.email}</p>
                </div>
                <span className="text-sm font-medium text-blue-700 bg-blue-50 px-3 py-1 rounded-full">
                  {p.ownership_share}% participación
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-green-50 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <TrendingUp size={16} className="text-green-600" />
                    <p className="text-xs text-green-600">Aportes</p>
                  </div>
                  <p className="text-sm font-bold text-green-700">{formatCOP(p.contributions)}</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <TrendingDown size={16} className="text-red-600" />
                    <p className="text-xs text-red-600">Retiros</p>
                  </div>
                  <p className="text-sm font-bold text-red-700">{formatCOP(p.withdrawals)}</p>
                </div>
                <div className="bg-blue-50 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Wallet size={16} className="text-blue-600" />
                    <p className="text-xs text-blue-600">Ganancias</p>
                  </div>
                  <p className="text-sm font-bold text-blue-700">{formatCOP(p.profits)}</p>
                </div>
                <div className="bg-slate-50 rounded-lg p-3">
                  <p className="text-xs text-slate-500 mb-1">Saldo actual</p>
                  <p className="text-sm font-bold text-slate-800">{formatCOP(p.balance)}</p>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-slate-700 mb-2">Historial</h4>
                {p.transactions.length === 0 ? (
                  <p className="text-sm text-slate-400">Sin movimientos</p>
                ) : (
                  <div className="max-h-40 overflow-y-auto space-y-1.5">
                    {p.transactions.map((t) => (
                      <div key={t.id} className="flex items-center justify-between text-sm border-b border-slate-50 pb-1.5">
                        <div>
                          <span className="font-medium text-slate-700">{TX_LABELS[t.type] ?? t.type}</span>
                          <span className="text-xs text-slate-400 ml-2">{formatDate(t.transaction_date)}</span>
                        </div>
                        <span className={`font-medium ${
                          t.type === 'withdrawal' ? 'text-red-600' : 'text-green-600'
                        }`}>
                          {t.type === 'withdrawal' ? '-' : '+'}{formatCOP(t.amount)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <BiometricSecurity />

      {/* Invite Partner Modal */}
      <Modal
        open={inviteOpen}
        onClose={() => setInviteOpen(false)}
        title="Invitar Nuevo Socio"
        size="md"
      >
        <form onSubmit={handleInvite} className="space-y-4">
          <div className="bg-blue-50 rounded-lg p-3 text-sm text-blue-700">
            Va a crear una cuenta para el segundo socio. Esta persona podra iniciar sesion con su correo y contraseña.
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Nombre completo *</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="text"
                value={inviteForm.name}
                onChange={(e) => setInviteForm({ ...inviteForm, name: e.target.value })}
                className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                placeholder="Nombre del socio"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Correo electrónico *</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="email"
                value={inviteForm.email}
                onChange={(e) => setInviteForm({ ...inviteForm, email: e.target.value })}
                className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                placeholder="correo@ejemplo.com"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Contraseña temporal *</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="password"
                value={inviteForm.password}
                onChange={(e) => setInviteForm({ ...inviteForm, password: e.target.value })}
                className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                placeholder="Mínimo 6 caracteres"
                required
              />
            </div>
            <p className="text-xs text-slate-400 mt-1">El socio podra cambiar su contraseña despues de iniciar sesion.</p>
          </div>
          {inviteError && <div className="text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg p-3">{inviteError}</div>}
          {inviteSuccess && <div className="text-sm bg-green-50 text-green-700 border border-green-200 rounded-lg p-3">{inviteSuccess}</div>}
          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={() => setInviteOpen(false)} className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium">
              Cancelar
            </button>
            <button type="submit" disabled={inviting} className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-medium disabled:opacity-50">
              {inviting ? 'Creando...' : 'Crear Socio'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
