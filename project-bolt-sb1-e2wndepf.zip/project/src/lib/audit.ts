import { supabase } from '@/lib/supabase';

export async function logAudit(
  action: string,
  entityType: string,
  entityId: string | null = null,
  details: Record<string, unknown> = {}
) {
  const { data: userData } = await supabase.auth.getUser();
  await supabase.from('audit_log').insert({
    user_id: userData.user?.id ?? null,
    user_email: userData.user?.email ?? null,
    action,
    entity_type: entityType,
    entity_id: entityId,
    details,
  });
}
