import {
  browserSupportsWebAuthn,
  startAuthentication,
  startRegistration,
  type PublicKeyCredentialCreationOptionsJSON,
  type PublicKeyCredentialRequestOptionsJSON,
} from '@simplewebauthn/browser';
import { supabase } from '@/lib/supabase';

export interface PasskeyInfo {
  id: string;
  device_name: string;
  transports: string[];
  created_at: string;
  last_used_at: string | null;
}

class PasskeyError extends Error {}

const FUNCTION_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/passkeys`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const DEVICE_CANCELLED = 'Se canceló o no se completó la verificación con su dispositivo.';

export function passkeysSupported(): boolean {
  return browserSupportsWebAuthn();
}

export function toUserMessage(err: unknown): string {
  return err instanceof PasskeyError ? err.message : 'Ocurrió un error. Intente de nuevo.';
}

async function callPasskeys<T>(
  path: string,
  options: { method: 'GET' | 'POST'; body?: unknown; authenticated: boolean },
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    apikey: ANON_KEY,
  };
  if (options.authenticated) {
    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;
    if (!token) throw new PasskeyError('Debe iniciar sesión para administrar sus dispositivos.');
    headers.Authorization = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await fetch(`${FUNCTION_URL}${path}`, {
      method: options.method,
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    });
  } catch {
    throw new PasskeyError('No hay conexión. Intente de nuevo.');
  }

  const json = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new PasskeyError(typeof json.error === 'string' ? json.error : 'No se pudo completar la operación.');
  }
  return json as T;
}

export async function registerPasskey(deviceName: string): Promise<PasskeyInfo> {
  const options = await callPasskeys<PublicKeyCredentialCreationOptionsJSON>('/register/options', {
    method: 'POST',
    body: {},
    authenticated: true,
  });

  let response;
  try {
    response = await startRegistration({ optionsJSON: options });
  } catch {
    throw new PasskeyError(DEVICE_CANCELLED);
  }

  const result = await callPasskeys<{ passkey: PasskeyInfo }>('/register/verify', {
    method: 'POST',
    body: { response, deviceName },
    authenticated: true,
  });
  return result.passkey;
}

export async function authenticateWithPasskey(): Promise<void> {
  const options = await callPasskeys<PublicKeyCredentialRequestOptionsJSON>('/authenticate/options', {
    method: 'POST',
    body: {},
    authenticated: false,
  });

  let response;
  try {
    response = await startAuthentication({ optionsJSON: options });
  } catch {
    throw new PasskeyError(DEVICE_CANCELLED);
  }

  const { tokenHash } = await callPasskeys<{ tokenHash: string; type: 'magiclink' }>('/authenticate/verify', {
    method: 'POST',
    body: { response },
    authenticated: false,
  });

  const { error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type: 'magiclink' });
  if (error) throw new PasskeyError('No se pudo iniciar la sesión con este dispositivo.');
}

export async function listPasskeys(): Promise<PasskeyInfo[]> {
  const result = await callPasskeys<{ passkeys: PasskeyInfo[] }>('/list', {
    method: 'GET',
    authenticated: true,
  });
  return result.passkeys;
}

export async function removePasskey(id: string): Promise<void> {
  await callPasskeys<{ success: boolean }>('/remove', {
    method: 'POST',
    body: { id },
    authenticated: true,
  });
}
