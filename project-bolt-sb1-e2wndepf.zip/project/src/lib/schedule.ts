import type { LoanFrequency } from '@/types';

export interface ScheduleConfig {
  capital: number;
  interestRate: number;
  disbursementDate: string;
  termDays: number;
  frequency: LoanFrequency;
  collectionDays: string[];
  excludeSundays: boolean;
  excludeHolidays: boolean;
  customDates: string[];
}

export interface GeneratedInstallment {
  installment_number: number;
  due_date: string;
  amount: number;
  capital_component: number;
  interest_component: number;
}

const DAY_NAMES = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
const DAY_ES: Record<string, string> = {
  sunday: 'Domingo',
  monday: 'Lunes',
  tuesday: 'Martes',
  wednesday: 'Miércoles',
  thursday: 'Jueves',
  friday: 'Viernes',
  saturday: 'Sábado',
};

export function dayNameEs(date: Date): string {
  return DAY_ES[DAY_NAMES[date.getDay()]];
}

function isExcluded(date: Date, excludeSundays: boolean, _excludeHolidays: boolean): boolean {
  if (excludeSundays && date.getDay() === 0) return true;
  return false;
}

function addDays(date: Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

export function generateSchedule(config: ScheduleConfig): GeneratedInstallment[] {
  const interest = (config.capital * config.interestRate) / 100;
  const totalToRecover = config.capital + interest;

  const dueDates = generateDueDates(config);
  if (dueDates.length === 0) return [];

  const numInstallments = dueDates.length;
  const baseAmount = Math.floor(totalToRecover / numInstallments);
  const lastAmount = totalToRecover - baseAmount * (numInstallments - 1);

  const interestPerInstallment = interest / numInstallments;
  const capitalPerInstallment = config.capital / numInstallments;

  const installments: GeneratedInstallment[] = dueDates.map((dueDate, i) => {
    const isLast = i === numInstallments - 1;
    const amount = isLast ? lastAmount : baseAmount;
    return {
      installment_number: i + 1,
      due_date: dueDate,
      amount: Math.round(amount),
      capital_component: Math.round(capitalPerInstallment),
      interest_component: Math.round(interestPerInstallment),
    };
  });

  return installments;
}

function generateDueDates(config: ScheduleConfig): string[] {
  const startDate = new Date(config.disbursementDate);
  const dates: string[] = [];
  const maxIterations = 365 * 3;
  let iterations = 0;

  if (config.frequency === 'custom_dates' && config.customDates.length > 0) {
    return [...config.customDates].sort();
  }

  if (config.frequency === 'daily') {
    let current = addDays(startDate, 1);
    while (dates.length < 365 && iterations < maxIterations) {
      if (!isExcluded(current, config.excludeSundays, config.excludeHolidays)) {
        dates.push(current.toISOString().split('T')[0]);
      }
      current = addDays(current, 1);
      iterations++;
      const lastDate = dates.length > 0 ? new Date(dates[dates.length - 1]) : startDate;
      const elapsed = Math.floor((lastDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      if (elapsed >= config.termDays && dates.length > 0) break;
    }
    return dates;
  }

  const stepMap: Record<string, number> = {
    weekly: 7,
    biweekly: 14,
    monthly: 30,
    custom_days: 1,
  };

  const step = stepMap[config.frequency] || 1;

  if (config.frequency === 'weekly' || config.frequency === 'biweekly' || config.frequency === 'monthly') {
    let current = addDays(startDate, step);
    while (iterations < maxIterations) {
      if (!isExcluded(current, config.excludeSundays, config.excludeHolidays)) {
        dates.push(current.toISOString().split('T')[0]);
      }
      const lastDate = dates.length > 0 ? new Date(dates[dates.length - 1]) : startDate;
      const elapsed = Math.floor((lastDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      if (elapsed >= config.termDays && dates.length > 0) break;
      current = addDays(current, step);
      iterations++;
    }
    return dates;
  }

  if (config.frequency === 'custom_days' && config.collectionDays.length > 0) {
    const selectedDayIndices = config.collectionDays.map((d) => DAY_NAMES.indexOf(d.toLowerCase())).filter((d) => d >= 0);
    let current = addDays(startDate, 1);
    while (iterations < maxIterations) {
      if (selectedDayIndices.includes(current.getDay()) && !isExcluded(current, config.excludeSundays, config.excludeHolidays)) {
        dates.push(current.toISOString().split('T')[0]);
      }
      const lastDate = dates.length > 0 ? new Date(dates[dates.length - 1]) : startDate;
      const elapsed = Math.floor((lastDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      if (elapsed >= config.termDays && dates.length > 0) break;
      current = addDays(current, 1);
      iterations++;
    }
    return dates;
  }

  return dates;
}

export function getBusinessDaysBetween(startDate: string, endDate: string, excludeSundays: boolean): number {
  const start = new Date(startDate);
  const end = new Date(endDate);
  let count = 0;
  const current = new Date(start);
  while (current <= end) {
    if (!isExcluded(current, excludeSundays, false)) {
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  return count;
}

export function getOverdueDays(dueDate: string, excludeSundays: boolean): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(dueDate);
  due.setHours(0, 0, 0, 0);
  if (today <= due) return 0;
  return getBusinessDaysBetween(due.toISOString().split('T')[0], today.toISOString().split('T')[0], excludeSundays);
}
