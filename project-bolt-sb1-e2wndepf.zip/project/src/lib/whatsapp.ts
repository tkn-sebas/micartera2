import { supabase } from '@/lib/supabase';
import { formatCOP, formatDate } from '@/lib/format';
import type { Installment, Client, Loan } from '@/types';

interface WhatsAppNotification {
  phone: string;
  message: string;
  type: 'reminder' | 'overdue' | 'confirmation';
}

export async function buildPaymentReminder(
  installment: Installment,
  client: Client | undefined,
  loan: Loan | undefined
): Promise<WhatsAppNotification | null> {
  if (!client?.phone) return null;

  const message = [
    `Hola ${client.full_name},`,
    ``,
    `Le recordamos su cuota #${installment.installment_number} de ${formatCOP(installment.amount)}.`,
    `Fecha de vencimiento: ${formatDate(installment.due_date)}.`,
    ``,
    `Saldo pendiente de la cuota: ${formatCOP(installment.amount - installment.amount_paid)}.`,
    loan ? `Total pendiente del préstamo: ${formatCOP(loan.capital_pending + loan.interest_pending)}` : '',
    ``,
    `Gracias,`,
    `MI CARTERA`,
  ].filter(Boolean).join('\n');

  return {
    phone: client.phone,
    message,
    type: installment.due_date < new Date().toISOString().split('T')[0] ? 'overdue' : 'reminder',
  };
}

export async function buildPaymentConfirmation(
  clientName: string,
  phone: string | null,
  amount: number,
  paymentDate: string,
): Promise<WhatsAppNotification | null> {
  if (!phone) return null;

  const message = [
    `Hola ${clientName},`,
    ``,
    `Hemos registrado su pago de ${formatCOP(amount)}.`,
    `Fecha: ${formatDate(paymentDate)}.`,
    ``,
    `Gracias por su pago.`,
    `MI CARTERA`,
  ].join('\n');

  return {
    phone,
    message,
    type: 'confirmation',
  };
}

const NOTIFICATIONS_QUEUE_TABLE = 'whatsapp_notifications_queue';

export async function queueNotification(notification: WhatsAppNotification): Promise<void> {
  await supabase.from(NOTIFICATIONS_QUEUE_TABLE).insert({
    phone: notification.phone,
    message: notification.message,
    notification_type: notification.type,
    status: 'pending',
  });
}

export async function getPendingNotifications(): Promise<WhatsAppNotification[]> {
  const { data } = await supabase
    .from(NOTIFICATIONS_QUEUE_TABLE)
    .select('*')
    .eq('status', 'pending')
    .order('created_at', { ascending: true });
  return (data as WhatsAppNotification[]) ?? [];
}
