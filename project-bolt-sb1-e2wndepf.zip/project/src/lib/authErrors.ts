const AUTH_ERROR_MESSAGES: Record<string, string> = {
  invalid_credentials: 'Correo o contraseña incorrectos.',
  email_not_confirmed: 'Su correo aún no está confirmado. Revise su bandeja de entrada.',
  over_email_send_rate_limit: 'Ya se envió un código hace poco. Espere un minuto e intente de nuevo.',
  over_request_rate_limit: 'Demasiados intentos. Espere unos minutos e intente de nuevo.',
  otp_expired: 'El código venció. Solicite uno nuevo.',
  same_password: 'La nueva contraseña debe ser diferente a la anterior.',
  weak_password: 'La contraseña es muy débil. Use al menos 6 caracteres.',
  user_already_exists: 'No se pudo crear la cuenta con ese correo.',
  email_exists: 'No se pudo crear la cuenta con ese correo.',
  session_not_found: 'Su sesión venció. Vuelva a solicitar el código de recuperación.',
};

export function translateAuthError(error: { code?: string }): string {
  return (error.code && AUTH_ERROR_MESSAGES[error.code]) || 'Ocurrió un error. Intente de nuevo.';
}
