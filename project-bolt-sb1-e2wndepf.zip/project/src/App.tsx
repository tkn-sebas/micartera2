import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { LoginScreen } from '@/components/LoginScreen';
import { Layout, type ViewKey } from '@/components/Layout';
import { Dashboard } from '@/views/Dashboard';
import { Clients } from '@/views/Clients';
import { Loans } from '@/views/Loans';
import { CalendarView } from '@/views/Calendar';
import { Payments } from '@/views/Payments';
import { Mora } from '@/views/Mora';
import { Cash } from '@/views/Cash';
import { Partners } from '@/views/Partners';
import { Profits } from '@/views/Profits';
import { Reports } from '@/views/Reports';

function AppContent() {
  const { user, accessStatus, loading, recovering } = useAuth();
  const [view, setView] = useState<ViewKey>('dashboard');
  const [newLoanSignal, setNewLoanSignal] = useState(0);

  useEffect(() => {
    if (!user) setView('dashboard');
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block w-10 h-10 border-4 border-blue-400 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-blue-200 text-sm">Cargando MI CARTERA...</p>
        </div>
      </div>
    );
  }

  // Si no hay sesión o el usuario no es socio autorizado, mostrar pantalla de login
  // (LoginScreen internally handles the "no_partner" case with an access denied view)
  if (recovering || !user || accessStatus !== 'authorized') {
    return <LoginScreen />;
  }

  function handleNewLoan() {
    setView('loans');
    setNewLoanSignal((s) => s + 1);
  }

  return (
    <Layout currentView={view} onNavigate={setView} onNewLoan={handleNewLoan}>
      {view === 'dashboard' && <Dashboard onNavigate={setView} onNewLoan={handleNewLoan} />}
      {view === 'clients' && <Clients />}
      {view === 'loans' && <Loans newLoanSignal={newLoanSignal} />}
      {view === 'calendar' && <CalendarView />}
      {view === 'payments' && <Payments />}
      {view === 'mora' && <Mora />}
      {view === 'cash' && <Cash />}
      {view === 'partners' && <Partners />}
      {view === 'profits' && <Profits />}
      {view === 'reports' && <Reports />}
    </Layout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
