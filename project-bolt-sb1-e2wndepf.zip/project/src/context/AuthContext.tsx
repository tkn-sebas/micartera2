import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import type { Partner } from '@/types';
import { translateAuthError } from '@/lib/authErrors';
import { authenticateWithPasskey, toUserMessage } from '@/lib/passkeys';

type AccessStatus = 'loading' | 'authorized' | 'no_partner' | 'slots_full' | 'signed_out';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  partner: Partner | null;
  accessStatus: AccessStatus;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, name: string) => Promise<{ error: string | null }>;
  signInWithPasskey: () => Promise<{ error: string | null }>;
  resetPassword: (email: string) => Promise<{ error: string | null }>;
  verifyRecoveryCode: (email: string, code: string) => Promise<{ error: string | null }>;
  updatePassword: (password: string) => Promise<{ error: string | null }>;
  recovering: boolean;
  endRecovery: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [partner, setPartner] = useState<Partner | null>(null);
  const [accessStatus, setAccessStatus] = useState<AccessStatus>('loading');
  const [loading, setLoading] = useState(true);
  const [recovering, setRecovering] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setUser(data.session?.user ?? null);
      if (data.session?.user) {
        (async () => {
          await loadPartner(data.session.user.id);
          setLoading(false);
        })();
      } else {
        setAccessStatus('signed_out');
        setLoading(false);
      }
    });

    const { data: sub } = supabase.auth.onAuthStateChange((event, newSession) => {
      if (event === 'PASSWORD_RECOVERY') setRecovering(true);
      setSession(newSession);
      setUser(newSession?.user ?? null);
      if (newSession?.user) {
        (async () => {
          await loadPartner(newSession.user.id);
          setLoading(false);
        })();
      } else {
        setPartner(null);
        setAccessStatus('signed_out');
        setLoading(false);
      }
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  async function loadPartner(userId: string) {
    const { data } = await supabase
      .from('partners')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (data) {
      setPartner(data as Partner);
      setAccessStatus('authorized');
    } else {
      setPartner(null);
      setAccessStatus('no_partner');
    }
  }

  async function signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error ? translateAuthError(error) : null };
  }

  async function signUp(email: string, password: string, name: string) {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { error: translateAuthError(error) };
    if (data.user) {
      const { error: partnerErr } = await supabase.from('partners').insert({
        user_id: data.user.id,
        name,
        email,
        ownership_share: 50.0,
      });
      if (partnerErr) {
        if (partnerErr.code === '42501') {
          return { error: 'Ya existen 2 socios registrados. No se permiten más cuentas.' };
        }
        return { error: 'No se pudo completar el registro. Intente de nuevo.' };
      }
    }
    return { error: null };
  }

  async function signInWithPasskey() {
    try {
      await authenticateWithPasskey();
      return { error: null };
    } catch (err) {
      return { error: toUserMessage(err) };
    }
  }

  async function resetPassword(email: string) {
    const { error } = await supabase.auth.resetPasswordForEmail(email);
    return { error: error ? translateAuthError(error) : null };
  }

  async function verifyRecoveryCode(email: string, code: string) {
    const { error } = await supabase.auth.verifyOtp({ email, token: code, type: 'recovery' });
    if (!error) setRecovering(true);
    return { error: error ? translateAuthError(error) : null };
  }

  async function updatePassword(password: string) {
    const { error } = await supabase.auth.updateUser({ password });
    if (error) return { error: translateAuthError(error) };
    await supabase.auth.signOut();
    return { error: null };
  }

  async function endRecovery() {
    await supabase.auth.signOut();
    setRecovering(false);
  }

  async function signOut() {
    await supabase.auth.signOut();
    setPartner(null);
    setAccessStatus('signed_out');
  }

  return (
    <AuthContext.Provider value={{ session, user, partner, accessStatus, loading, signIn, signInWithPasskey, signUp, resetPassword, verifyRecoveryCode, updatePassword, recovering, endRecovery, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
