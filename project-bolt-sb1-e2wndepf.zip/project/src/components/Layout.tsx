import { useState, ReactNode } from 'react';
import { useAuth } from '@/context/AuthContext';
import {
  LayoutDashboard,
  Users,
  HandCoins,
  Calendar,
  Banknote,
  AlertTriangle,
  Wallet,
  UserCircle2,
  PieChart,
  FileBarChart,
  LogOut,
  Menu,
  X,
  PlusCircle,
} from 'lucide-react';

export type ViewKey =
  | 'dashboard'
  | 'clients'
  | 'loans'
  | 'calendar'
  | 'payments'
  | 'mora'
  | 'cash'
  | 'partners'
  | 'profits'
  | 'reports';

interface NavItem {
  key: ViewKey;
  label: string;
  icon: typeof LayoutDashboard;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'dashboard', label: 'Inicio', icon: LayoutDashboard },
  { key: 'clients', label: 'Clientes', icon: Users },
  { key: 'loans', label: 'Préstamos', icon: HandCoins },
  { key: 'calendar', label: 'Calendario', icon: Calendar },
  { key: 'payments', label: 'Pagos', icon: Banknote },
  { key: 'mora', label: 'Mora', icon: AlertTriangle },
  { key: 'cash', label: 'Caja', icon: Wallet },
  { key: 'partners', label: 'Socios', icon: UserCircle2 },
  { key: 'profits', label: 'Utilidades', icon: PieChart },
  { key: 'reports', label: 'Reportes', icon: FileBarChart },
];

interface LayoutProps {
  currentView: ViewKey;
  onNavigate: (view: ViewKey) => void;
  onNewLoan: () => void;
  children: ReactNode;
}

export function Layout({ currentView, onNavigate, onNewLoan, children }: LayoutProps) {
  const { partner, signOut } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const currentItem = NAV_ITEMS.find((n) => n.key === currentView);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-slate-900/50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-blue-900 text-white flex flex-col z-40 transition-transform duration-200 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center gap-3 px-5 py-5 border-b border-blue-800">
          <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
            <Wallet size={22} />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">MI CARTERA</h1>
            <p className="text-blue-300 text-xs">Préstamos</p>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="ml-auto lg:hidden text-blue-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = currentView === item.key;
            return (
              <button
                key={item.key}
                onClick={() => {
                  onNavigate(item.key);
                  setSidebarOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  active
                    ? 'bg-white text-blue-900 shadow-sm'
                    : 'text-blue-100 hover:bg-blue-800'
                }`}
              >
                <Icon size={18} />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-blue-800 p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 bg-blue-700 rounded-full flex items-center justify-center text-sm font-semibold">
              {partner?.name?.charAt(0).toUpperCase() ?? '?'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{partner?.name ?? 'Socio'}</p>
              <p className="text-xs text-blue-300 truncate">{partner?.email}</p>
            </div>
          </div>
          <button
            onClick={signOut}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-blue-200 hover:bg-blue-800 transition-colors"
          >
            <LogOut size={16} />
            Cerrar sesión
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-slate-200 px-4 lg:px-6 py-4 flex items-center gap-4 sticky top-0 z-20">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden text-slate-600"
          >
            <Menu size={22} />
          </button>
          <h2 className="text-lg font-semibold text-slate-900 flex-1">
            {currentItem?.label}
          </h2>
          {currentView === 'dashboard' && (
            <button
              onClick={onNewLoan}
              className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg font-medium text-sm transition-colors whitespace-nowrap"
            >
              <PlusCircle size={18} />
              <span className="hidden sm:inline">Nuevo Préstamo</span>
              <span className="sm:hidden">Préstamo</span>
            </button>
          )}
        </header>

        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">{children}</main>
      </div>
    </div>
  );
}
