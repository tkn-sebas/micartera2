import { useState, FormEvent, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Wallet, Lock, Mail, User, ShieldAlert, LogIn, UserPlus, KeyRound, Hash, CheckCircle2, Fingerprint } from 'lucide-react';
import { passkeysSupported } from '@/lib/passkeys';

type Mode = 'login' | 'signup' | 'forgot';

export function LoginScreen() {
  const { signIn, signInWithPasskey, signUp, resetPassword, verifyRecoveryCode, updatePassword, recovering, endRecovery, accessStatus, user, signOut } = useAuth();
  const [mode, setMode] = useState<Mode>('login');
  const [codeSent, setCodeSent] = useState(false);
  const [code, setCode] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [registrationOpen, setRegistrationOpen] = useState(false);
  const [resendIn, setResendIn] = useState(0);

  useEffect(() => {
    if (resendIn <= 0) return;
    const timer = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [resendIn]);

  useEffect(() => {
    supabase.functions.invoke<{ registrationOpen: boolean }>('registration-status').then(({ data, error }) => {
      if (error || typeof data?.registrationOpen !== 'boolean') return;
      setRegistrationOpen(data.registrationOpen);
    });
  }, []);

  if (recovering) {
    return <NewPasswordCard onSubmit={updatePassword} onExit={endRecovery} />;
  }

  // Si el usuario está autenticado pero no es socio, mostrar pantalla de acceso denegado
  if (user && accessStatus === 'no_partner') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
          <div className="bg-red-700 px-8 py-10 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mb-4">
              <ShieldAlert className="text-white" size={32} />
            </div>
            <h1 className="text-xl font-bold text-white">Acceso No Autorizado</h1>
          </div>
          <div className="px-8 py-8 text-center">
            <p className="text-slate-700 mb-2">
              Su cuenta no pertenece a los socios autorizados de este negocio.
            </p>
            <p className="text-sm text-slate-500 mb-6">
              Solo los dos socios registrados pueden acceder a MI CARTERA.
              Si cree que esto es un error, contacte al administrador.
            </p>
            <button
              onClick={signOut}
              className="w-full bg-slate-700 hover:bg-slate-800 text-white font-semibold py-2.5 rounded-lg transition-colors"
            >
              Cerrar sesión
            </button>
          </div>
        </div>
      </div>
    );
  }

  async function handlePasskeySignIn() {
    setError(null);
    setSuccess(null);
    setLoading(true);
    const { error } = await signInWithPasskey();
    if (error) {
      setError(error);
      setLoading(false);
    }
  }

  function switchMode(next: Mode) {
    setMode(next);
    setCodeSent(false);
    setCode('');
    setError(null);
    setSuccess(null);
  }

  async function handleResend() {
    setError(null);
    setSuccess(null);
    setLoading(true);
    const { error } = await resetPassword(email);
    setLoading(false);
    if (error) {
      setError(error);
    } else {
      setResendIn(60);
      setSuccess('Enviamos un nuevo código a su correo.');
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    if (mode === 'login') {
      const { error } = await signIn(email, password);
      if (error) setError(error);
    } else if (mode === 'forgot' && !codeSent) {
      const { error } = await resetPassword(email);
      if (error) {
        setError(error);
      } else {
        setCodeSent(true);
        setResendIn(60);
        setSuccess('Enviamos un código de 6 números a su correo. Revise también la carpeta de spam.');
      }
    } else if (mode === 'forgot') {
      const { error } = await verifyRecoveryCode(email, code.trim());
      if (error) setError('El código es incorrecto o ya venció. Revise el código o pida uno nuevo.');
    } else {
      if (name.trim().length < 2) {
        setError('Ingrese su nombre completo');
        setLoading(false);
        return;
      }
      if (password.length < 6) {
        setError('La contraseña debe tener al menos 6 caracteres');
        setLoading(false);
        return;
      }

      const { error } = await signUp(email, password, name);
      if (error) {
        setError(error);
      } else {
        setSuccess('Cuenta creada exitosamente. Ahora inicie sesión.');
        setMode('login');
        setPassword('');
      }
    }
    setLoading(false);
  }

  const isForgot = mode === 'forgot';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        <div className="bg-blue-900 px-8 py-10 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mb-4">
            <Wallet className="text-white" size={32} />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">MI CARTERA</h1>
          <p className="text-blue-200 text-sm mt-1">Gestión de Préstamos</p>
        </div>

        <div className="px-8 py-8">
          {isForgot ? (
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-slate-900">Recuperar contraseña</h2>
              <p className="text-sm text-slate-500 mt-1">
                {codeSent
                  ? 'Escriba el código de 6 números que le llegó al correo.'
                  : 'Escriba su correo y le enviaremos un código para crear una nueva contraseña.'}
              </p>
            </div>
          ) : (
            <div className="flex gap-2 mb-6 bg-slate-100 p-1 rounded-lg">
              <button
                onClick={() => switchMode('login')}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center gap-1.5 ${
                  mode === 'login' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-500'
                }`}
              >
                <LogIn size={15} />
                Iniciar Sesión
              </button>
              {registrationOpen && (
                <button
                  onClick={() => switchMode('signup')}
                  className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center gap-1.5 ${
                    mode === 'signup' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-500'
                  }`}
                >
                  <UserPlus size={15} />
                  Registrar Primer Socio
                </button>
              )}
            </div>
          )}

          {mode === 'signup' && (
            <div className="mb-4 text-sm rounded-lg p-3 bg-blue-50 text-blue-700 border border-blue-200">
              Este registro crea la cuenta del primer socio. El segundo socio debera ser invitado desde dentro de la aplicacion.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Nombre completo</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                    placeholder="Su nombre"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Correo electrónico</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all disabled:bg-slate-100 disabled:text-slate-500"
                  placeholder="correo@ejemplo.com"
                  disabled={isForgot && codeSent}
                  required
                />
              </div>
            </div>

            {isForgot && codeSent && (
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Código de 6 números</label>
                <div className="relative">
                  <Hash className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="text"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    maxLength={6}
                    value={code}
                    onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                    className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg tracking-[0.4em] text-center text-lg font-semibold focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                    placeholder="000000"
                    required
                  />
                </div>
              </div>
            )}

            {!isForgot && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-sm font-medium text-slate-700">Contraseña</label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => switchMode('forgot')}
                      className="text-xs font-medium text-blue-700 hover:text-blue-900 hover:underline"
                    >
                      ¿Olvidaste tu contraseña?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                    placeholder="Mínimo 6 caracteres"
                    required
                  />
                </div>
              </div>
            )}

            {error && (
              <div className="text-sm rounded-lg p-3 bg-red-50 text-red-700 border border-red-200">
                {error}
              </div>
            )}
            {success && (
              <div className="text-sm rounded-lg p-3 bg-green-50 text-green-700 border border-green-200">
                {success}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-700 hover:bg-blue-800 text-white font-semibold py-2.5 rounded-lg transition-colors disabled:opacity-50"
            >
              {loading
                ? 'Procesando...'
                : isForgot
                  ? codeSent ? 'Verificar código' : 'Enviar código'
                  : mode === 'login'
                    ? 'Ingresar'
                    : 'Crear Cuenta'}
            </button>
          </form>

          {mode === 'login' && passkeysSupported() && (
            <div className="mt-4">
              <div className="flex items-center gap-3 my-4">
                <div className="flex-1 h-px bg-slate-200" />
                <span className="text-xs text-slate-400">o</span>
                <div className="flex-1 h-px bg-slate-200" />
              </div>
              <button
                type="button"
                onClick={handlePasskeySignIn}
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 border border-blue-700 text-blue-800 hover:bg-blue-50 font-semibold py-2.5 rounded-lg transition-colors disabled:opacity-50"
              >
                <Fingerprint size={18} />
                Ingresar con huella o Face ID
              </button>
            </div>
          )}

          {isForgot && codeSent && (
            <button
              type="button"
              onClick={handleResend}
              disabled={loading || resendIn > 0}
              className="w-full text-sm text-blue-700 hover:text-blue-900 hover:underline mt-4 disabled:text-slate-400 disabled:no-underline"
            >
              {resendIn > 0 ? `Reenviar código en ${resendIn} s` : 'Reenviar código'}
            </button>
          )}
          {isForgot && (
            <button
              type="button"
              onClick={() => switchMode('login')}
              className="w-full text-sm text-blue-700 hover:text-blue-900 hover:underline mt-2"
            >
              Volver a iniciar sesión
            </button>
          )}

          <p className="text-xs text-slate-400 text-center mt-6">
            Solo los socios autorizados pueden acceder al sistema.
          </p>
        </div>
      </div>
    </div>
  );
}

function NewPasswordCard({
  onSubmit,
  onExit,
}: {
  onSubmit: (password: string) => Promise<{ error: string | null }>;
  onExit: () => Promise<void>;
}) {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres');
      return;
    }
    if (password !== confirm) {
      setError('Las contraseñas no coinciden');
      return;
    }
    setLoading(true);
    const { error } = await onSubmit(password);
    setLoading(false);
    if (error) setError(error);
    else setDone(true);
  }

  if (done) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
          <div className="bg-green-700 px-8 py-10 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mb-4">
              <CheckCircle2 className="text-white" size={32} />
            </div>
            <h1 className="text-xl font-bold text-white">Contraseña actualizada</h1>
          </div>
          <div className="px-8 py-8 text-center">
            <p className="text-slate-700 mb-6">
              Su contraseña se cambió correctamente. Inicie sesión con su nueva contraseña.
            </p>
            <button
              onClick={onExit}
              className="w-full bg-blue-700 hover:bg-blue-800 text-white font-semibold py-2.5 rounded-lg transition-colors"
            >
              Iniciar sesión
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        <div className="bg-blue-900 px-8 py-10 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mb-4">
            <KeyRound className="text-white" size={32} />
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">Nueva contraseña</h1>
          <p className="text-blue-200 text-sm mt-1">Escriba la contraseña que usará a partir de ahora</p>
        </div>

        <form onSubmit={handleSubmit} className="px-8 py-8 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Nueva contraseña</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                placeholder="Mínimo 6 caracteres"
                required
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Repita la contraseña</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                className="w-full pl-10 pr-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
                required
              />
            </div>
          </div>
          {error && (
            <div className="text-sm rounded-lg p-3 bg-red-50 text-red-700 border border-red-200">{error}</div>
          )}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-700 hover:bg-blue-800 text-white font-semibold py-2.5 rounded-lg transition-colors disabled:opacity-50"
          >
            {loading ? 'Guardando...' : 'Guardar contraseña'}
          </button>
          <button
            type="button"
            onClick={onExit}
            disabled={loading}
            className="w-full text-sm text-slate-500 hover:text-slate-700 hover:underline"
          >
            Cancelar y volver al inicio de sesión
          </button>
        </form>
      </div>
    </div>
  );
}
