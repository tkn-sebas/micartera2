import { useEffect, useState, FormEvent } from 'react';
import { Fingerprint, Plus, Smartphone, Trash2 } from 'lucide-react';
import {
  listPasskeys,
  passkeysSupported,
  registerPasskey,
  removePasskey,
  toUserMessage,
  type PasskeyInfo,
} from '@/lib/passkeys';

const MAX_NAME_LENGTH = 60;

function formatWhen(value: string | null): string {
  if (!value) return 'Nunca';
  return new Date(value).toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function BiometricSecurity() {
  const [supported] = useState(passkeysSupported);
  const [passkeys, setPasskeys] = useState<PasskeyInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [adding, setAdding] = useState(false);
  const [deviceName, setDeviceName] = useState('');
  const [confirmRemoveId, setConfirmRemoveId] = useState<string | null>(null);
  const [confirmDisable, setConfirmDisable] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    listPasskeys()
      .then((items) => {
        if (!cancelled) setPasskeys(items);
      })
      .catch((err) => {
        if (!cancelled) setError(toUserMessage(err));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function reload() {
    try {
      setPasskeys(await listPasskeys());
    } catch (err) {
      setError(toUserMessage(err));
    }
  }

  async function handleAdd(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    const name = deviceName.trim();
    if (name.length < 1 || name.length > MAX_NAME_LENGTH) {
      setError(`Indique un nombre para el dispositivo (1 a ${MAX_NAME_LENGTH} caracteres)`);
      return;
    }
    setBusy(true);
    try {
      await registerPasskey(name);
      setAdding(false);
      setDeviceName('');
      setSuccess('Dispositivo registrado. Ya puede ingresar con huella o Face ID desde él.');
      await reload();
    } catch (err) {
      setError(toUserMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleRemove(id: string) {
    setError(null);
    setSuccess(null);
    setBusy(true);
    try {
      await removePasskey(id);
      setConfirmRemoveId(null);
      setSuccess('Dispositivo eliminado.');
      await reload();
    } catch (err) {
      setError(toUserMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function handleDisable() {
    setError(null);
    setSuccess(null);
    setBusy(true);
    try {
      for (const passkey of passkeys) {
        await removePasskey(passkey.id);
      }
      setConfirmDisable(false);
      setSuccess('Acceso biométrico desactivado. Puede seguir ingresando con su contraseña.');
      await reload();
    } catch (err) {
      setError(toUserMessage(err));
      await reload();
    } finally {
      setBusy(false);
    }
  }

  const hasPasskeys = passkeys.length > 0;

  return (
    <section className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center text-blue-700">
          <Fingerprint size={20} />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-slate-900">Seguridad y acceso biométrico</h3>
          <p className="text-sm text-slate-500">
            Ingrese con la huella, Face ID o el bloqueo de su dispositivo, sin escribir la contraseña.
          </p>
        </div>
      </div>

      {!supported ? (
        <div className="text-sm rounded-lg p-3 bg-amber-50 text-amber-800 border border-amber-200">
          Este navegador no admite acceso biométrico. Use una versión actualizada de Chrome, Safari o Edge en una conexión segura (HTTPS).
        </div>
      ) : loading ? (
        <p className="text-sm text-slate-400">Cargando dispositivos...</p>
      ) : (
        <div className="space-y-4">
          {hasPasskeys && (
            <ul className="divide-y divide-slate-100 border border-slate-200 rounded-lg">
              {passkeys.map((passkey) => (
                <li key={passkey.id} className="flex items-center gap-3 p-3">
                  <Smartphone size={18} className="text-slate-400 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800 truncate">{passkey.device_name}</p>
                    <p className="text-xs text-slate-500">
                      Registrado: {formatWhen(passkey.created_at)} · Último uso: {formatWhen(passkey.last_used_at)}
                    </p>
                  </div>
                  {confirmRemoveId === passkey.id ? (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleRemove(passkey.id)}
                        disabled={busy}
                        className="text-xs font-semibold text-white bg-red-600 hover:bg-red-700 px-3 py-1.5 rounded-md disabled:opacity-50"
                      >
                        Eliminar
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmRemoveId(null)}
                        disabled={busy}
                        className="text-xs font-medium text-slate-600 hover:text-slate-800 px-2 py-1.5"
                      >
                        Cancelar
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmRemoveId(passkey.id)}
                      disabled={busy}
                      aria-label={`Eliminar ${passkey.device_name}`}
                      className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors disabled:opacity-50"
                    >
                      <Trash2 size={16} />
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}

          {adding ? (
            <form onSubmit={handleAdd} className="space-y-3 border border-blue-200 bg-blue-50/50 rounded-lg p-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Nombre del dispositivo</label>
                <input
                  type="text"
                  value={deviceName}
                  onChange={(e) => setDeviceName(e.target.value)}
                  maxLength={MAX_NAME_LENGTH}
                  placeholder="Ej. Mi teléfono Android"
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                  required
                />
                <p className="text-xs text-slate-500 mt-1">
                  Se abrirá la ventana de su dispositivo para confirmar con huella o Face ID.
                </p>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setAdding(false);
                    setError(null);
                  }}
                  disabled={busy}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-sm font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={busy}
                  className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-sm font-medium disabled:opacity-50"
                >
                  {busy ? 'Esperando a su dispositivo...' : 'Registrar dispositivo'}
                </button>
              </div>
            </form>
          ) : (
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  setAdding(true);
                  setError(null);
                  setSuccess(null);
                }}
                disabled={busy}
                className="flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
              >
                <Plus size={16} />
                {hasPasskeys ? 'Registrar otro dispositivo' : 'Activar acceso biométrico'}
              </button>
              {hasPasskeys &&
                (confirmDisable ? (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleDisable}
                      disabled={busy}
                      className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-medium disabled:opacity-50"
                    >
                      Sí, desactivar
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDisable(false)}
                      disabled={busy}
                      className="px-3 py-2 text-sm font-medium text-slate-600 hover:text-slate-800"
                    >
                      No
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmDisable(true)}
                    disabled={busy}
                    className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 text-sm font-medium disabled:opacity-50"
                  >
                    Desactivar acceso biométrico
                  </button>
                ))}
            </div>
          )}

          {error && <div className="text-sm rounded-lg p-3 bg-red-50 text-red-700 border border-red-200">{error}</div>}
          {success && <div className="text-sm rounded-lg p-3 bg-green-50 text-green-700 border border-green-200">{success}</div>}
        </div>
      )}
    </section>
  );
}
