import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2";
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
  type RegistrationResponseJSON,
  type AuthenticationResponseJSON,
} from "npm:@simplewebauthn/server@13";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const CHALLENGE_TTL_MS = 5 * 60 * 1000;
const MAX_PASSKEYS_PER_ACCOUNT = 10;
const RP_NAME = "MI CARTERA";

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function toBase64url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromBase64url(value: string): Uint8Array {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - (value.length % 4)) % 4);
  return Uint8Array.from(atob(padded), (c) => c.charCodeAt(0));
}

function rpIdFromOrigin(origin: string | null): { origin: string; rpId: string } | null {
  if (!origin) return null;
  let url: URL;
  try {
    url = new URL(origin);
  } catch {
    return null;
  }
  const isLocal = url.hostname === "localhost" && url.protocol === "http:";
  if (url.protocol !== "https:" && !isLocal) return null;
  return { origin: url.origin, rpId: url.hostname };
}

function challengeFromResponse(response: { response?: { clientDataJSON?: unknown } }): string | null {
  const clientDataJSON = response?.response?.clientDataJSON;
  if (typeof clientDataJSON !== "string") return null;
  try {
    const parsed = JSON.parse(new TextDecoder().decode(fromBase64url(clientDataJSON)));
    return typeof parsed.challenge === "string" ? parsed.challenge : null;
  } catch {
    return null;
  }
}

async function storeChallenge(
  admin: SupabaseClient,
  challenge: string,
  purpose: "register" | "authenticate",
  userId: string | null,
  rpId: string,
) {
  await admin.from("passkey_challenges").delete().lt("expires_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());
  return admin.from("passkey_challenges").insert({
    challenge,
    purpose,
    user_id: userId,
    rp_id: rpId,
    expires_at: new Date(Date.now() + CHALLENGE_TTL_MS).toISOString(),
  });
}

async function consumeChallenge(
  admin: SupabaseClient,
  challenge: string,
  purpose: "register" | "authenticate",
  userId: string | null,
  rpId: string,
): Promise<boolean> {
  let query = admin
    .from("passkey_challenges")
    .update({ used_at: new Date().toISOString() })
    .eq("challenge", challenge)
    .eq("purpose", purpose)
    .eq("rp_id", rpId)
    .is("used_at", null)
    .gt("expires_at", new Date().toISOString());
  query = userId ? query.eq("user_id", userId) : query.is("user_id", null);
  const { data, error } = await query.select("id");
  return !error && (data?.length ?? 0) === 1;
}

async function requireUser(req: Request): Promise<{ id: string; email: string } | null> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return null;
  const userClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
    auth: { autoRefreshToken: false, persistSession: false },
    global: { headers: { Authorization: authHeader } },
  });
  const { data, error } = await userClient.auth.getUser();
  if (error || !data.user || !data.user.email) return null;
  return { id: data.user.id, email: data.user.email };
}

async function registerOptions(admin: SupabaseClient, user: { id: string; email: string }, rpId: string) {
  const { data: existing, error } = await admin
    .from("user_passkeys")
    .select("credential_id, transports")
    .eq("user_id", user.id);
  if (error) return json({ error: "No se pudo preparar el registro" }, 500);

  const options = await generateRegistrationOptions({
    rpName: RP_NAME,
    rpID: rpId,
    userName: user.email,
    userDisplayName: user.email,
    userID: new TextEncoder().encode(user.id),
    attestationType: "none",
    excludeCredentials: (existing ?? []).map((c) => ({
      id: c.credential_id,
      transports: c.transports as AuthenticatorTransportFuture[],
    })),
    authenticatorSelection: { residentKey: "required", userVerification: "required" },
  });

  const { error: storeErr } = await storeChallenge(admin, options.challenge, "register", user.id, rpId);
  if (storeErr) return json({ error: "No se pudo preparar el registro" }, 500);
  return json(options);
}

type AuthenticatorTransportFuture = "ble" | "cable" | "hybrid" | "internal" | "nfc" | "smart-card" | "usb";

async function registerVerify(admin: SupabaseClient, user: { id: string }, rpId: string, origin: string, body: { response?: RegistrationResponseJSON; deviceName?: unknown }) {
  const deviceName = typeof body.deviceName === "string" ? body.deviceName.trim() : "";
  if (!body.response || deviceName.length < 1 || deviceName.length > 60) {
    return json({ error: "Indique un nombre para el dispositivo (1 a 60 caracteres)" }, 400);
  }

  const { count } = await admin
    .from("user_passkeys")
    .select("id", { count: "exact", head: true })
    .eq("user_id", user.id);
  if ((count ?? 0) >= MAX_PASSKEYS_PER_ACCOUNT) {
    return json({ error: "Ya tiene el máximo de dispositivos registrados" }, 400);
  }

  const challenge = challengeFromResponse(body.response as never);
  if (!challenge || !(await consumeChallenge(admin, challenge, "register", user.id, rpId))) {
    return json({ error: "El desafío venció o ya fue usado. Intente de nuevo." }, 400);
  }

  let verification;
  try {
    verification = await verifyRegistrationResponse({
      response: body.response,
      expectedChallenge: challenge,
      expectedOrigin: origin,
      expectedRPID: rpId,
      requireUserVerification: true,
    });
  } catch {
    return json({ error: "No se pudo verificar el dispositivo" }, 400);
  }
  if (!verification.verified || !verification.registrationInfo) {
    return json({ error: "No se pudo verificar el dispositivo" }, 400);
  }

  const credential = verification.registrationInfo.credential;
  const { data, error } = await admin
    .from("user_passkeys")
    .insert({
      user_id: user.id,
      credential_id: credential.id,
      public_key: toBase64url(credential.publicKey),
      counter: credential.counter,
      transports: credential.transports ?? [],
      device_name: deviceName,
      rp_id: rpId,
    })
    .select("id, device_name, created_at")
    .single();
  if (error || !data) {
    return json({ error: "Este dispositivo ya está registrado" }, 409);
  }
  return json({ success: true, passkey: data });
}

async function authenticateOptions(admin: SupabaseClient, rpId: string) {
  const options = await generateAuthenticationOptions({
    rpID: rpId,
    userVerification: "required",
    allowCredentials: [],
  });
  const { error } = await storeChallenge(admin, options.challenge, "authenticate", null, rpId);
  if (error) return json({ error: "No se pudo iniciar el acceso" }, 500);
  return json(options);
}

async function authenticateVerify(admin: SupabaseClient, rpId: string, origin: string, body: { response?: AuthenticationResponseJSON }) {
  const denied = () => json({ error: "No se pudo verificar el acceso con este dispositivo" }, 401);
  if (!body.response || typeof body.response.id !== "string") return denied();

  const { data: passkey } = await admin
    .from("user_passkeys")
    .select("*")
    .eq("credential_id", body.response.id)
    .maybeSingle();
  if (!passkey || passkey.rp_id !== rpId) return denied();

  const challenge = challengeFromResponse(body.response as never);
  if (!challenge || !(await consumeChallenge(admin, challenge, "authenticate", null, rpId))) {
    return denied();
  }

  let verification;
  try {
    verification = await verifyAuthenticationResponse({
      response: body.response,
      expectedChallenge: challenge,
      expectedOrigin: origin,
      expectedRPID: passkey.rp_id,
      credential: {
        id: passkey.credential_id,
        publicKey: fromBase64url(passkey.public_key),
        counter: Number(passkey.counter),
        transports: passkey.transports as AuthenticatorTransportFuture[],
      },
      requireUserVerification: true,
    });
  } catch {
    return denied();
  }
  if (!verification.verified) return denied();

  await admin
    .from("user_passkeys")
    .update({ counter: verification.authenticationInfo.newCounter, last_used_at: new Date().toISOString() })
    .eq("id", passkey.id);

  const { data: account, error: accountErr } = await admin.auth.admin.getUserById(passkey.user_id);
  if (accountErr || !account.user?.email) return denied();

  const { data: link, error: linkErr } = await admin.auth.admin.generateLink({
    type: "magiclink",
    email: account.user.email,
  });
  if (linkErr || !link.properties?.hashed_token) {
    return json({ error: "No se pudo iniciar la sesión" }, 500);
  }
  return json({ tokenHash: link.properties.hashed_token, type: "magiclink" });
}

async function listPasskeys(admin: SupabaseClient, user: { id: string }) {
  const { data, error } = await admin
    .from("user_passkeys")
    .select("id, device_name, transports, created_at, last_used_at")
    .eq("user_id", user.id)
    .order("created_at", { ascending: true });
  if (error) return json({ error: "No se pudieron cargar los dispositivos" }, 500);
  return json({ passkeys: data ?? [] });
}

async function removePasskey(admin: SupabaseClient, user: { id: string }, body: { id?: unknown }) {
  if (typeof body.id !== "string" || !/^[0-9a-f-]{36}$/i.test(body.id)) {
    return json({ error: "Dispositivo no válido" }, 400);
  }
  const { data, error } = await admin
    .from("user_passkeys")
    .delete()
    .eq("id", body.id)
    .eq("user_id", user.id)
    .select("id");
  if (error) return json({ error: "No se pudo eliminar el dispositivo" }, 500);
  if (!data || data.length === 0) return json({ error: "Dispositivo no encontrado" }, 404);
  return json({ success: true });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const route = new URL(req.url).pathname.replace(/^.*\/passkeys/, "");
    const origin = rpIdFromOrigin(req.headers.get("Origin"));
    if (!origin) {
      return json({ error: "Origen no permitido. El acceso biométrico requiere HTTPS." }, 400);
    }

    const admin = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "", {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const rpId = origin.rpId;

    if (req.method === "POST" && route === "/authenticate/options") {
      return await authenticateOptions(admin, rpId);
    }
    if (req.method === "POST" && route === "/authenticate/verify") {
      return await authenticateVerify(admin, rpId, origin.origin, await req.json());
    }

    const user = await requireUser(req);
    if (!user) {
      return json({ error: "Debe iniciar sesión" }, 401);
    }

    if (req.method === "POST" && route === "/register/options") {
      return await registerOptions(admin, user, rpId);
    }
    if (req.method === "POST" && route === "/register/verify") {
      return await registerVerify(admin, user, rpId, origin.origin, await req.json());
    }
    if (req.method === "GET" && route === "/list") {
      return await listPasskeys(admin, user);
    }
    if (req.method === "POST" && route === "/remove") {
      return await removePasskey(admin, user, await req.json());
    }

    return json({ error: "Ruta no encontrada" }, 404);
  } catch (err) {
    console.error("passkeys request failed", err);
    return json({ error: "Error interno. Intente de nuevo." }, 500);
  }
});
