/*
# Fix anon grants on whatsapp_notifications_queue

The whatsapp_notifications_queue table was created with default grants
that gave anon full CRUD. Revoke all anon privileges — only authenticated
partners should access this table.
*/

REVOKE ALL ON whatsapp_notifications_queue FROM anon;
REVOKE UPDATE, DELETE ON whatsapp_notifications_queue FROM authenticated;
GRANT SELECT, INSERT ON whatsapp_notifications_queue TO authenticated;
