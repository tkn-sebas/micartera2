/*
# Restrict grants on financial tables

## Changes
1. Revoke excessive privileges from `anon` role on all business tables.
   The app requires authentication, so `anon` should not have any grants.
2. Revoke UPDATE and DELETE from `payments` and `payment_reversals` tables
   to enforce that payments cannot be edited or deleted directly.
3. Revoke DELETE from `cash_transactions`, `partner_transactions`, and `audit_log`
   to preserve financial history.
4. Keep `authenticated` SELECT/INSERT on all tables, plus UPDATE where needed.

## Security
- `anon` role loses all privileges on business tables (no policies exist for anon).
- `payments` table: only SELECT and INSERT for `authenticated` (no UPDATE/DELETE).
- `audit_log` table: only SELECT and INSERT for `authenticated` (no UPDATE/DELETE).
- `partner_transactions`: only SELECT and INSERT (no UPDATE/DELETE).
- `cash_transactions`: only SELECT and INSERT (no UPDATE/DELETE).
- `installments`: SELECT, INSERT, UPDATE (no DELETE — preserves schedule history).
- `clients`: SELECT, INSERT, UPDATE (no DELETE — preserves client records).
- `loans`: SELECT, INSERT, UPDATE (no DELETE — preserves loan records).
*/

-- Revoke all from anon on all business tables
REVOKE ALL ON clients FROM anon;
REVOKE ALL ON loans FROM anon;
REVOKE ALL ON installments FROM anon;
REVOKE ALL ON payments FROM anon;
REVOKE ALL ON payment_reversals FROM anon;
REVOKE ALL ON cash_transactions FROM anon;
REVOKE ALL ON partner_transactions FROM anon;
REVOKE ALL ON partners FROM anon;
REVOKE ALL ON audit_log FROM anon;

-- Revoke UPDATE/DELETE from payments (payments are immutable, corrected via reversal)
REVOKE UPDATE, DELETE ON payments FROM authenticated;
GRANT SELECT, INSERT ON payments TO authenticated;

-- Revoke UPDATE/DELETE from payment_reversals
REVOKE UPDATE, DELETE ON payment_reversals FROM authenticated;
GRANT SELECT, INSERT ON payment_reversals TO authenticated;

-- Revoke UPDATE/DELETE from audit_log (audit trail is immutable)
REVOKE UPDATE, DELETE ON audit_log FROM authenticated;
GRANT SELECT, INSERT ON audit_log TO authenticated;

-- Revoke UPDATE/DELETE from cash_transactions
REVOKE UPDATE, DELETE ON cash_transactions FROM authenticated;
GRANT SELECT, INSERT ON cash_transactions TO authenticated;

-- Revoke UPDATE/DELETE from partner_transactions
REVOKE UPDATE, DELETE ON partner_transactions FROM authenticated;
GRANT SELECT, INSERT ON partner_transactions TO authenticated;

-- Ensure clients has only SELECT, INSERT, UPDATE (no DELETE)
REVOKE DELETE ON clients FROM authenticated;
GRANT SELECT, INSERT, UPDATE ON clients TO authenticated;

-- Ensure loans has only SELECT, INSERT, UPDATE (no DELETE)
REVOKE DELETE ON loans FROM authenticated;
GRANT SELECT, INSERT, UPDATE ON loans TO authenticated;

-- Ensure installments has only SELECT, INSERT, UPDATE (no DELETE)
REVOKE DELETE ON installments FROM authenticated;
GRANT SELECT, INSERT, UPDATE ON installments TO authenticated;

-- Partners: keep SELECT for all authenticated, INSERT/UPDATE for own profile
GRANT SELECT, INSERT, UPDATE ON partners TO authenticated;
