/*
# Move partner helper functions out of the public API

1. Summary
- The helper functions `is_authorized_partner()` and `can_register_partner()` are used by the database access rules that protect every table. They are now moved into a private schema that the web API does not expose, so they can no longer be called directly by signed-in users over the web API.
- The function `get_partner_count()` is only used by the login screen. It is no longer callable by any role; the login screen call was already failing for visitors who are not signed in.

2. New schema
- `private` schema holds the helper functions. Only signed-in users get usage on it, which is needed so the access rules can run.

3. Modified access rules
- Every access rule on the tables that referenced the old public helpers now references the private copies. The rules themselves (who can read or write) are unchanged.

4. Removed public objects
- The old public copies of `is_authorized_partner()` and `can_register_partner()` are dropped once no rule uses them.

5. Security notes
- Helper functions still run with elevated rights, which is required so the access rules can read the partners table without looping back on themselves.
- No table data is modified or deleted.
*/

CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC;
GRANT USAGE ON SCHEMA private TO authenticated;

CREATE OR REPLACE FUNCTION private.is_authorized_partner()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $function$
SELECT EXISTS (
  SELECT 1 FROM partners
  WHERE partners.user_id = auth.uid()
);
$function$;

CREATE OR REPLACE FUNCTION private.can_register_partner()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $function$
SELECT (SELECT count(*) FROM partners) < 2;
$function$;

REVOKE EXECUTE ON FUNCTION private.is_authorized_partner() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION private.can_register_partner() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.is_authorized_partner() TO authenticated;
GRANT EXECUTE ON FUNCTION private.can_register_partner() TO authenticated;

ALTER POLICY "audit_insert_authorized" ON audit_log WITH CHECK (private.is_authorized_partner());
ALTER POLICY "audit_select_authorized" ON audit_log USING (private.is_authorized_partner());

ALTER POLICY "cash_insert_authorized" ON cash_transactions WITH CHECK (private.is_authorized_partner());
ALTER POLICY "cash_select_authorized" ON cash_transactions USING (private.is_authorized_partner());

ALTER POLICY "clients_insert_authorized" ON clients WITH CHECK (private.is_authorized_partner());
ALTER POLICY "clients_select_authorized" ON clients USING (private.is_authorized_partner());
ALTER POLICY "clients_update_authorized" ON clients USING (private.is_authorized_partner()) WITH CHECK (private.is_authorized_partner());

ALTER POLICY "installments_insert_authorized" ON installments WITH CHECK (private.is_authorized_partner());
ALTER POLICY "installments_select_authorized" ON installments USING (private.is_authorized_partner());
ALTER POLICY "installments_update_authorized" ON installments USING (private.is_authorized_partner()) WITH CHECK (private.is_authorized_partner());

ALTER POLICY "loans_insert_authorized" ON loans WITH CHECK (private.is_authorized_partner());
ALTER POLICY "loans_select_authorized" ON loans USING (private.is_authorized_partner());
ALTER POLICY "loans_update_authorized" ON loans USING (private.is_authorized_partner()) WITH CHECK (private.is_authorized_partner());

ALTER POLICY "partner_tx_insert_authorized" ON partner_transactions WITH CHECK (private.is_authorized_partner());
ALTER POLICY "partner_tx_select_authorized" ON partner_transactions USING (private.is_authorized_partner());

ALTER POLICY "partners_insert_own" ON partners WITH CHECK ((auth.uid() = user_id) AND private.can_register_partner());
ALTER POLICY "partners_select_authorized" ON partners USING (private.is_authorized_partner());

ALTER POLICY "reversals_insert_authorized" ON payment_reversals WITH CHECK (private.is_authorized_partner());
ALTER POLICY "reversals_select_authorized" ON payment_reversals USING (private.is_authorized_partner());

ALTER POLICY "payments_insert_authorized" ON payments WITH CHECK (private.is_authorized_partner());
ALTER POLICY "payments_select_authorized" ON payments USING (private.is_authorized_partner());

ALTER POLICY "wa_insert_authorized" ON whatsapp_notifications_queue WITH CHECK (private.is_authorized_partner());
ALTER POLICY "wa_select_authorized" ON whatsapp_notifications_queue USING (private.is_authorized_partner());

DROP FUNCTION IF EXISTS public.is_authorized_partner();
DROP FUNCTION IF EXISTS public.can_register_partner();

REVOKE EXECUTE ON FUNCTION public.get_partner_count() FROM PUBLIC, anon, authenticated;
