/*
# WhatsApp notifications queue table

## Purpose
Stores pending WhatsApp notifications for future sending when the
WhatsApp API integration is activated in a second phase.
This is structural preparation only — no external service is called.

## Table
- `whatsapp_notifications_queue`
  - phone (text) — recipient phone number
  - message (text) — message body
  - notification_type (text) — reminder | overdue | confirmation
  - status (text) — pending | sent | failed
  - sent_at (timestamptz, nullable)
  - error_message (text, nullable)
  - created_at (timestamptz)

## Security
- RLS enabled, only authorized partners can read/insert.
- No UPDATE/DELETE granted (notifications are immutable once queued).
*/

CREATE TABLE IF NOT EXISTS whatsapp_notifications_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone text NOT NULL,
  message text NOT NULL,
  notification_type text NOT NULL CHECK (notification_type IN ('reminder', 'overdue', 'confirmation')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed')),
  sent_at timestamptz,
  error_message text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE whatsapp_notifications_queue ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON whatsapp_notifications_queue TO authenticated;

DROP POLICY IF EXISTS "wa_select_authorized" ON whatsapp_notifications_queue;
CREATE POLICY "wa_select_authorized" ON whatsapp_notifications_queue FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "wa_insert_authorized" ON whatsapp_notifications_queue;
CREATE POLICY "wa_insert_authorized" ON whatsapp_notifications_queue FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());
