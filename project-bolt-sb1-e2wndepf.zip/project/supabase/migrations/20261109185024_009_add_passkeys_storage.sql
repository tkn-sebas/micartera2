/*
# Add passkey (biometric sign-in) storage

1. Summary
- Adds storage for WebAuthn passkeys so one account can register several devices (fingerprint, Face ID, Touch ID, device unlock).
- Adds a short-lived challenge table so every sign-in or registration challenge is random, single-use and expires.
- No existing table, user, client, payment, or financial record is changed.

2. New tables
- `user_passkeys`: one row per registered device. Holds the public key, signature counter, transports, a device name chosen by the user, the domain the passkey belongs to, and created/last used dates. It never stores fingerprints, face data, or private keys, because those never leave the device.
- `passkey_challenges`: one row per challenge issued. Holds the random challenge, its purpose (register or authenticate), the owner when known, the expiry time, and the time it was used.

3. Security changes
- Row level security is enabled on both tables.
- Signed-in users may only read their own passkeys. They cannot insert, change, or delete rows directly; all changes go through the server function, which checks identity first.
- Challenges are not readable or writable by signed-in users or anonymous visitors. Only the server function (service role) can use them.

4. Important notes
- Deleting a user account removes their passkeys and challenges automatically.
- Each passkey row is tied to one account, so the same account can hold many passkeys.
*/

CREATE TABLE IF NOT EXISTS user_passkeys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  credential_id text NOT NULL UNIQUE,
  public_key text NOT NULL,
  counter bigint NOT NULL DEFAULT 0,
  transports text[] NOT NULL DEFAULT '{}',
  device_name text NOT NULL,
  rp_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz
);

CREATE INDEX IF NOT EXISTS user_passkeys_user_id_idx ON user_passkeys (user_id);

CREATE TABLE IF NOT EXISTS passkey_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge text NOT NULL UNIQUE,
  purpose text NOT NULL CHECK (purpose IN ('register', 'authenticate')),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  rp_id text NOT NULL,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS passkey_challenges_expires_at_idx ON passkey_challenges (expires_at);

ALTER TABLE user_passkeys ENABLE ROW LEVEL SECURITY;
ALTER TABLE passkey_challenges ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON user_passkeys FROM PUBLIC, anon;
REVOKE ALL ON passkey_challenges FROM PUBLIC, anon, authenticated;

GRANT SELECT ON user_passkeys TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON user_passkeys TO service_role;
GRANT SELECT, INSERT, UPDATE, DELETE ON passkey_challenges TO service_role;

DROP POLICY IF EXISTS "select_own_passkeys" ON user_passkeys;
CREATE POLICY "select_own_passkeys" ON user_passkeys FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
