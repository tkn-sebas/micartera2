/*
# MI CARTERA - Esquema inicial completo

## Descripción
Aplicación de gestión financiera para un pequeño negocio de préstamos manejado por dos socios.
Incluye autenticación, clientes, préstamos, cuotas, pagos, caja, socios y auditoría.

## Tablas nuevas
1. `partners` - Perfiles de los socios (vinculados a auth.users)
2. `clients` - Clientes del negocio de préstamos
3. `loans` - Préstamos desembolsados a clientes
4. `installments` - Cuotas del calendario de cobro de cada préstamo
5. `payments` - Pagos y abonos recibidos (no editables ni borrables directamente)
6. `payment_reversals` - Reversiones de pagos con motivo, usuario y fecha
7. `cash_transactions` - Movimientos de caja (aportes, retiros, desembolsos, gastos, etc.)
8. `partner_transactions` - Movimientos individuales de cada socio (aportes, retiros, ganancias)
9. `audit_log` - Registro de auditoría de todas las operaciones

## Seguridad
- RLS habilitado en todas las tablas
- Solo usuarios autenticados (los dos socios) pueden acceder a los datos
- Políticas de propiedad basadas en auth.uid()
- Todos los datos son compartidos entre los dos socios (ambos tienen los mismos permisos)
- El historial financiero (pagos) no se puede borrar ni editar directamente
*/

-- ============================================
-- Tabla: partners (perfiles de socios)
-- ============================================
CREATE TABLE IF NOT EXISTS partners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text NOT NULL,
  ownership_share numeric(5,2) NOT NULL DEFAULT 50.00 CHECK (ownership_share >= 0 AND ownership_share <= 100),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE partners ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON partners TO authenticated;

DROP POLICY IF EXISTS "partners_select_all" ON partners;
CREATE POLICY "partners_select_all" ON partners FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "partners_insert_own" ON partners;
CREATE POLICY "partners_insert_own" ON partners FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "partners_update_own" ON partners;
CREATE POLICY "partners_update_own" ON partners FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ============================================
-- Tabla: clients (clientes)
-- ============================================
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  id_number text NOT NULL,
  phone text,
  address text,
  registration_date date NOT NULL DEFAULT CURRENT_DATE,
  notes text,
  active boolean NOT NULL DEFAULT true,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON clients TO authenticated;

DROP POLICY IF EXISTS "clients_select_all" ON clients;
CREATE POLICY "clients_select_all" ON clients FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "clients_insert_auth" ON clients;
CREATE POLICY "clients_insert_auth" ON clients FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "clients_update_auth" ON clients;
CREATE POLICY "clients_update_auth" ON clients FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- Índice para búsqueda por identificación
CREATE INDEX IF NOT EXISTS idx_clients_id_number ON clients(id_number);

-- ============================================
-- Tabla: loans (préstamos)
-- ============================================
CREATE TABLE IF NOT EXISTS loans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
  capital numeric(15,2) NOT NULL CHECK (capital > 0),
  interest_rate numeric(5,2) NOT NULL CHECK (interest_rate >= 0),
  interest_amount numeric(15,2) NOT NULL DEFAULT 0,
  total_to_recover numeric(15,2) NOT NULL DEFAULT 0,
  disbursement_date date NOT NULL DEFAULT CURRENT_DATE,
  term_days integer NOT NULL CHECK (term_days > 0),
  frequency text NOT NULL DEFAULT 'daily' CHECK (frequency IN ('daily','weekly','biweekly','monthly','custom_days','custom_dates')),
  collection_days text[] NOT NULL DEFAULT '{}',
  exclude_sundays boolean NOT NULL DEFAULT true,
  exclude_holidays boolean NOT NULL DEFAULT false,
  custom_dates date[] NOT NULL DEFAULT '{}',
  num_installments integer NOT NULL DEFAULT 0,
  installment_amount numeric(15,2) NOT NULL DEFAULT 0,
  last_installment_amount numeric(15,2) NOT NULL DEFAULT 0,
  capital_paid numeric(15,2) NOT NULL DEFAULT 0,
  interest_paid numeric(15,2) NOT NULL DEFAULT 0,
  capital_pending numeric(15,2) NOT NULL DEFAULT 0,
  interest_pending numeric(15,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','completed','cancelled')),
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE loans ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON loans TO authenticated;

DROP POLICY IF EXISTS "loans_select_all" ON loans;
CREATE POLICY "loans_select_all" ON loans FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "loans_insert_auth" ON loans;
CREATE POLICY "loans_insert_auth" ON loans FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "loans_update_auth" ON loans;
CREATE POLICY "loans_update_auth" ON loans FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_loans_client_id ON loans(client_id);
CREATE INDEX IF NOT EXISTS idx_loans_status ON loans(status);

-- ============================================
-- Tabla: installments (cuotas del calendario)
-- ============================================
CREATE TABLE IF NOT EXISTS installments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_id uuid NOT NULL REFERENCES loans(id) ON DELETE CASCADE,
  installment_number integer NOT NULL,
  due_date date NOT NULL,
  amount numeric(15,2) NOT NULL,
  capital_component numeric(15,2) NOT NULL DEFAULT 0,
  interest_component numeric(15,2) NOT NULL DEFAULT 0,
  amount_paid numeric(15,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','partial','paid','overdue')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE installments ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON installments TO authenticated;

DROP POLICY IF EXISTS "installments_select_all" ON installments;
CREATE POLICY "installments_select_all" ON installments FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "installments_insert_auth" ON installments;
CREATE POLICY "installments_insert_auth" ON installments FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "installments_update_auth" ON installments;
CREATE POLICY "installments_update_auth" ON installments FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_installments_loan_id ON installments(loan_id);
CREATE INDEX IF NOT EXISTS idx_installments_due_date ON installments(due_date);
CREATE INDEX IF NOT EXISTS idx_installments_status ON installments(status);

-- ============================================
-- Tabla: payments (pagos y abonos - no editables ni borrables)
-- ============================================
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_id uuid NOT NULL REFERENCES loans(id) ON DELETE RESTRICT,
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
  installment_id uuid REFERENCES installments(id) ON DELETE SET NULL,
  amount numeric(15,2) NOT NULL CHECK (amount > 0),
  capital_applied numeric(15,2) NOT NULL DEFAULT 0,
  interest_applied numeric(15,2) NOT NULL DEFAULT 0,
  payment_date date NOT NULL DEFAULT CURRENT_DATE,
  payment_time time NOT NULL DEFAULT now()::time,
  payment_method text NOT NULL DEFAULT 'cash' CHECK (payment_method IN ('cash','transfer','other')),
  notes text,
  is_reversed boolean NOT NULL DEFAULT false,
  reversed_at timestamptz,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON payments TO authenticated;

DROP POLICY IF EXISTS "payments_select_all" ON payments;
CREATE POLICY "payments_select_all" ON payments FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "payments_insert_auth" ON payments;
CREATE POLICY "payments_insert_auth" ON payments FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_payments_loan_id ON payments(loan_id);
CREATE INDEX IF NOT EXISTS idx_payments_client_id ON payments(client_id);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);

-- ============================================
-- Tabla: payment_reversals (reversiones de pagos)
-- ============================================
CREATE TABLE IF NOT EXISTS payment_reversals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id uuid NOT NULL REFERENCES payments(id) ON DELETE RESTRICT,
  reason text NOT NULL,
  reversed_by uuid REFERENCES auth.users(id),
  reversed_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE payment_reversals ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON payment_reversals TO authenticated;

DROP POLICY IF EXISTS "reversals_select_all" ON payment_reversals;
CREATE POLICY "reversals_select_all" ON payment_reversals FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "reversals_insert_auth" ON payment_reversals;
CREATE POLICY "reversals_insert_auth" ON payment_reversals FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_reversals_payment_id ON payment_reversals(payment_id);

-- ============================================
-- Tabla: cash_transactions (movimientos de caja)
-- ============================================
CREATE TABLE IF NOT EXISTS cash_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('partner_contribution','disbursement','payment_received','withdrawal','expense','other_income','other_expense','profit_distribution')),
  amount numeric(15,2) NOT NULL CHECK (amount > 0),
  direction text NOT NULL CHECK (direction IN ('in','out')),
  description text,
  loan_id uuid REFERENCES loans(id) ON DELETE SET NULL,
  payment_id uuid REFERENCES payments(id) ON DELETE SET NULL,
  partner_id uuid REFERENCES partners(id) ON DELETE SET NULL,
  transaction_date date NOT NULL DEFAULT CURRENT_DATE,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE cash_transactions ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON cash_transactions TO authenticated;

DROP POLICY IF EXISTS "cash_select_all" ON cash_transactions;
CREATE POLICY "cash_select_all" ON cash_transactions FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "cash_insert_auth" ON cash_transactions;
CREATE POLICY "cash_insert_auth" ON cash_transactions FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_cash_date ON cash_transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_cash_type ON cash_transactions(type);

-- ============================================
-- Tabla: partner_transactions (movimientos individuales de socios)
-- ============================================
CREATE TABLE IF NOT EXISTS partner_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_id uuid NOT NULL REFERENCES partners(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('contribution','withdrawal','profit_distribution','reinvestment')),
  amount numeric(15,2) NOT NULL CHECK (amount > 0),
  description text,
  transaction_date date NOT NULL DEFAULT CURRENT_DATE,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE partner_transactions ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON partner_transactions TO authenticated;

DROP POLICY IF EXISTS "partner_tx_select_all" ON partner_transactions;
CREATE POLICY "partner_tx_select_all" ON partner_transactions FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "partner_tx_insert_auth" ON partner_transactions;
CREATE POLICY "partner_tx_insert_auth" ON partner_transactions FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_partner_tx_partner_id ON partner_transactions(partner_id);

-- ============================================
-- Tabla: audit_log (registro de auditoría)
-- ============================================
CREATE TABLE IF NOT EXISTS audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  user_email text,
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON audit_log TO authenticated;

DROP POLICY IF EXISTS "audit_select_all" ON audit_log;
CREATE POLICY "audit_select_all" ON audit_log FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "audit_insert_auth" ON audit_log;
CREATE POLICY "audit_insert_auth" ON audit_log FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity_type, entity_id);

-- ============================================
-- Función para actualizar updated_at
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_clients_updated_at ON clients;
CREATE TRIGGER trg_clients_updated_at BEFORE UPDATE ON clients
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trg_loans_updated_at ON loans;
CREATE TRIGGER trg_loans_updated_at BEFORE UPDATE ON loans
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
