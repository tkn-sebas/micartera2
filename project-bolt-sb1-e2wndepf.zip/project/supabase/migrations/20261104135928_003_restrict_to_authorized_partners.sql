/*
# Restringir acceso a solo socios autorizados

## Problema
Las políticas RLS actuales usan `USING (true)` para todos los usuarios autenticados.
Esto significa que CUALQUIER persona que cree una cuenta en Supabase Auth
tiene acceso completo a todos los datos financieros del negocio.

## Solución
1. Crear una función `is_authorized_partner()` que verifica si el usuario
   autenticado tiene un registro en la tabla `partners`.
2. Reescribir TODAS las políticas RLS para usar esta función en lugar de `true`.
3. Solo los dos socios que tengan un registro en `partners` pueden acceder a los datos.
4. Cualquier otra persona que se registre no verá ni podrá modificar nada.
5. Limitar el registro de nuevos socios: solo se permiten máximo 2.
6. Revocar el grant DELETE sobrante en `partners`.
7. Corregir el search_path de la función `update_updated_at`.

## Seguridad
- Acceso a TODAS las tablas restringido a socios autorizados únicamente.
- Un usuario autenticado sin registro en `partners` no ve ningún dato.
- Los socios comparten todos los datos (ambos tienen los mismos permisos).
- No se pueden eliminar perfiles de socios desde la API.
*/

-- ============================================
-- Función: is_authorized_partner()
-- Verifica si el usuario actual tiene un registro en partners
-- ============================================
CREATE OR REPLACE FUNCTION public.is_authorized_partner()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM partners
    WHERE partners.user_id = auth.uid()
  );
$$;

-- Solo usuarios autenticados pueden llamar esta función
REVOKE EXECUTE ON FUNCTION public.is_authorized_partner() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_authorized_partner() TO authenticated;

-- ============================================
-- Función: can_register_partner()
-- Verifica si se pueden registrar más socios (máximo 2)
-- ============================================
CREATE OR REPLACE FUNCTION public.can_register_partner()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT (SELECT count(*) FROM partners) < 2;
$$;

REVOKE EXECUTE ON FUNCTION public.can_register_partner() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_register_partner() TO authenticated;

-- ============================================
-- Corregir search_path de update_updated_at
-- ============================================
DROP TRIGGER IF EXISTS trg_clients_updated_at ON clients;
DROP TRIGGER IF EXISTS trg_loans_updated_at ON loans;
DROP FUNCTION IF EXISTS public.update_updated_at();

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_clients_updated_at BEFORE UPDATE ON clients
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER trg_loans_updated_at BEFORE UPDATE ON loans
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- ============================================
-- Revocar DELETE sobrante en partners
-- ============================================
REVOKE DELETE ON partners FROM authenticated;
GRANT SELECT, INSERT, UPDATE ON partners TO authenticated;

-- ============================================
-- Reescribir políticas RLS: clients
-- ============================================
DROP POLICY IF EXISTS "clients_select_all" ON clients;
CREATE POLICY "clients_select_authorized" ON clients FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "clients_insert_auth" ON clients;
CREATE POLICY "clients_insert_authorized" ON clients FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());

DROP POLICY IF EXISTS "clients_update_auth" ON clients;
CREATE POLICY "clients_update_authorized" ON clients FOR UPDATE
  TO authenticated USING (public.is_authorized_partner())
  WITH CHECK (public.is_authorized_partner());

-- ============================================
-- Reescribir políticas RLS: loans
-- ============================================
DROP POLICY IF EXISTS "loans_select_all" ON loans;
CREATE POLICY "loans_select_authorized" ON loans FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "loans_insert_auth" ON loans;
CREATE POLICY "loans_insert_authorized" ON loans FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());

DROP POLICY IF EXISTS "loans_update_auth" ON loans;
CREATE POLICY "loans_update_authorized" ON loans FOR UPDATE
  TO authenticated USING (public.is_authorized_partner())
  WITH CHECK (public.is_authorized_partner());

-- ============================================
-- Reescribir políticas RLS: installments
-- ============================================
DROP POLICY IF EXISTS "installments_select_all" ON installments;
CREATE POLICY "installments_select_authorized" ON installments FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "installments_insert_auth" ON installments;
CREATE POLICY "installments_insert_authorized" ON installments FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());

DROP POLICY IF EXISTS "installments_update_auth" ON installments;
CREATE POLICY "installments_update_authorized" ON installments FOR UPDATE
  TO authenticated USING (public.is_authorized_partner())
  WITH CHECK (public.is_authorized_partner());

-- ============================================
-- Reescribir políticas RLS: payments
-- ============================================
DROP POLICY IF EXISTS "payments_select_all" ON payments;
CREATE POLICY "payments_select_authorized" ON payments FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "payments_insert_auth" ON payments;
CREATE POLICY "payments_insert_authorized" ON payments FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());

-- ============================================
-- Reescribir políticas RLS: payment_reversals
-- ============================================
DROP POLICY IF EXISTS "reversals_select_all" ON payment_reversals;
CREATE POLICY "reversals_select_authorized" ON payment_reversals FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "reversals_insert_auth" ON payment_reversals;
CREATE POLICY "reversals_insert_authorized" ON payment_reversals FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());

-- ============================================
-- Reescribir políticas RLS: cash_transactions
-- ============================================
DROP POLICY IF EXISTS "cash_select_all" ON cash_transactions;
CREATE POLICY "cash_select_authorized" ON cash_transactions FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "cash_insert_auth" ON cash_transactions;
CREATE POLICY "cash_insert_authorized" ON cash_transactions FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());

-- ============================================
-- Reescribir políticas RLS: partner_transactions
-- ============================================
DROP POLICY IF EXISTS "partner_tx_select_all" ON partner_transactions;
CREATE POLICY "partner_tx_select_authorized" ON partner_transactions FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "partner_tx_insert_auth" ON partner_transactions;
CREATE POLICY "partner_tx_insert_authorized" ON partner_transactions FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());

-- ============================================
-- Reescribir políticas RLS: audit_log
-- ============================================
DROP POLICY IF EXISTS "audit_select_all" ON audit_log;
CREATE POLICY "audit_select_authorized" ON audit_log FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

DROP POLICY IF EXISTS "audit_insert_auth" ON audit_log;
CREATE POLICY "audit_insert_authorized" ON audit_log FOR INSERT
  TO authenticated WITH CHECK (public.is_authorized_partner());

-- ============================================
-- Reescribir políticas RLS: partners
-- Mantener INSERT/UPDATE propios pero verificar autorización para SELECT
-- ============================================
DROP POLICY IF EXISTS "partners_select_all" ON partners;
CREATE POLICY "partners_select_authorized" ON partners FOR SELECT
  TO authenticated USING (public.is_authorized_partner());

-- El INSERT de partners solo se permite si hay menos de 2 socios
-- y el usuario crea su propio perfil
DROP POLICY IF EXISTS "partners_insert_own" ON partners;
CREATE POLICY "partners_insert_own" ON partners FOR INSERT
  TO authenticated WITH CHECK (
    auth.uid() = user_id
    AND public.can_register_partner()
  );

DROP POLICY IF EXISTS "partners_update_own" ON partners;
CREATE POLICY "partners_update_own" ON partners FOR UPDATE
  TO authenticated USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
