/*
# Fix payment reversal permissions and add partner count function

## Problems fixed
1. `payments` table has no UPDATE grant — payment reversals fail with 42501.
   Reversals need to set `is_reversed = true` and `reversed_at`. We grant
   UPDATE only on those two columns (not the full row) so financial data
   (amount, capital_applied, interest_applied) remains immutable.
2. `checkRegistrationSlot()` in the frontend tries to SELECT count from
   partners, but RLS blocks non-partners. We add a SECURITY DEFINER function
   `get_partner_count()` that returns the count without RLS restrictions,
   and grant it to authenticated.
3. `partner_transactions` needs UPDATE for profit reinvestment adjustments.

## Security
- payments UPDATE restricted to (is_reversed, reversed_at) columns only.
- get_partner_count() is SECURITY DEFINER, search_path set, returns integer only.
- No new anon grants.
*/

-- Grant UPDATE only on reversal columns of payments
REVOKE UPDATE ON payments FROM authenticated;
GRANT UPDATE (is_reversed, reversed_at) ON payments TO authenticated;

-- Function to get partner count (callable by any authenticated user)
CREATE OR REPLACE FUNCTION public.get_partner_count()
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*)::integer FROM partners;
$$;

REVOKE EXECUTE ON FUNCTION public.get_partner_count() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_partner_count() TO authenticated;
