/*
# Remove unused partner count function

1. Summary
- Removes the database function that counted partners for the login screen. The login screen now asks a server function whether registration is still open, so this database function is no longer used.

2. Removed objects
- Function `public.get_partner_count()`.

3. Security notes
- Removing this function makes no change to any table or stored data.
- Partner access rules are unaffected.
*/

DROP FUNCTION IF EXISTS public.get_partner_count();
